<div style='display:none;' id='otherfilter'>

    <div class="col-md-12 twentyunderpad">

        <div class="col-md-6">

            <h2 class="titlepad">Subcategories</h2>

            <input type="text" name="subcategory[]" id="OtherOtsubcategory" placeholder="Add own suggestion"></input>

        </div>

        <div class="col-md-6">

            <h2 class="titlepad">Type</h2>

            <input type="text" name="type[]" id="OtherOttype" placeholder="Add own suggestion"></input>

        </div>

    </div>
    <div class="col-md-12 twentyunderpad">

        <div class="col-md-6">

            <h2 class="titlepad">Cost</h2>

            <input type="text" name="Cost[]" id="OtherOtCost" placeholder="Add own suggestion"></input>

        </div>

        <div class="col-md-6">

            <h2 class="titlepad">Extras</h2>

            <input type="text" name="Extras[]" id="OtherOtExtras" placeholder="Add own suggestion"></input>

        </div>

    </div>

    <div class="col-md-12 twentyunderpad">

        <div class="col-md-6">

        <h2 class="titlepad">Features</h2>

            <input type='checkbox' name="filters[]" value="Wifi" id="wifi"> Free Wifi</input><br>
            <input type='checkbox' name="filters[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input><br>
            <input type='checkbox' name="filters[]" value="Children friendly" class="childrenfriendly"> Children friendly</input><br>
            <input type='checkbox' name="filters[]" value="Dog friendly" class="dogfriendly"> Dog friendly</input><br>
            <input type='checkbox' name="filters[]" value="Bike friendly" class="bikefriendly"> Bike friendly</input><br>
            <input type='checkbox' name="filters[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input><br>
            <input type='checkbox' name="filters[]" value="Female toilet" class="femaletoilet"> Female toilet</input><br>
            <input type='checkbox' name="filters[]" value="Male toilet" class="maletoilet"> Male toilet</input><br> 

        </div>

        <div class="col-md-6">

            <h2 class="titlepad"></h2>

        </div>

    </div>

</div>