<div style='display:none;' id='retailshoppingfilter'>

    <div class="col-md-12 twentyunderpad">

        <div class="col-md-6">

            <h2 class="titlepad">Subcategories</h2>

            <input type='checkbox' name="subcategory[]" value="BooksMagazines" id="BooksMagazines"> Books / Magazines</input><br>
             <input type='checkbox' name="subcategory[]" value="Building" id="Building"> Building</input><br>
            <input type='checkbox' name="subcategory[]" value="Clothing" id="Clothing"> Clothing</input><br>
            <input type='checkbox' name="subcategory[]" value="Computers" id="Computers"> Computers</input><br>
             <input type='checkbox' name="subcategory[]" value="Electrical" id="Electrical"> Electrical</input><br>
            <input type='checkbox' name="subcategory[]" value="Electronics" id="Electronics"> Electronics</input><br>
            <input type='checkbox' name="subcategory[]" value="Equipment" id="Equipment"> Equipment</input><br>
            <input type='checkbox' name="subcategory[]" value="Florist" id="Florist"> Florist</input><br>
            <input type='checkbox' name="subcategory[]" value="Footwear" id="Footwear"> Footwear</input><br>
            <input type='checkbox' name="subcategory[]" value="Furnishings" id="Furnishings"> Furnishings</input><br>
            <input type='checkbox' name="subcategory[]" value="GeneralStore" id="GeneralStore"> General store</input><br>
            <input type='checkbox' name="subcategory[]" value="Hardware" id="Hardware"> Hardware</input><br>
            <input type='checkbox' name="subcategory[]" value="Hire" id="Hire"> Hire</input><br>
            <input type='checkbox' name="subcategory[]" value="HobbyCrafts" id="HobbyCrafts"> Hobby / Crafts</input><br>
            <input type='checkbox' name="subcategory[]" value="Jewellers" id="Jewellers"> Jewellers</input><br>
            <input type='checkbox' name="subcategory[]" value="Paint" id="Paint"> Paint</input><br>
            <input type='checkbox' name="subcategory[]" value="Pharmacy" id="Pharmacy"> Pharmacy</input><br>
             <input type='checkbox' name="subcategory[]" value="Plumbing" id="Plumbing"> Plumbing</input><br>
            <input type='checkbox' name="subcategory[]" value="Safety" id="Safety"> Safety</input><br>
            <input type='checkbox' name="subcategory[]" value="Sports" id="Sports"> Sports</input><br>
            <input type='checkbox' name="subcategory[]" value="Tools" id="Tools"> Tools</input><br>
            <input type='checkbox' name="subcategory[]" value="SecondhandAntiques" id="SecondhandAntiques"> Secondhand / Antiques</input><br>
            <input type='checkbox' name="subcategory[]" value="Whiteware" id="Whiteware"> Whiteware</input><br>
            <input type="text" name="subcategory[]" id="OtherRSsubcategory" placeholder="Add own suggestion"></input>
           <!--  <input type='checkbox' name="subcategory[]" value="OtherRSSub" id="OtherRSSub"> Other</input><br> -->

        </div>

        <div class="col-md-6">

            <h2 class="titlepad">Features</h2>

            <input type='checkbox' name="filters[]" value="Wifi" id="wifi"> Free Wifi</input><br>
            <input type='checkbox' name="filters[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input><br>
            <input type='checkbox' name="filters[]" value="Children friendly" class="childrenfriendly"> Children friendly</input><br>
            <input type='checkbox' name="filters[]" value="Dog friendly" class="dogfriendly"> Dog friendly</input><br>
            <input type='checkbox' name="filters[]" value="Bike friendly" class="bikefriendly"> Bike friendly</input><br>
            <input type='checkbox' name="filters[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input><br>
            <input type='checkbox' name="filters[]" value="Female toilet" class="femaletoilet"> Female toilet</input><br>
            <input type='checkbox' name="filters[]" value="Male toilet" class="maletoilet"> Male toilet</input><br>  

        </div>

    </div>

</div>