<div style='display:none;' id='bankingfinancefilter'>

    <div class="col-md-12">

        <div class="col-md-6">

            <h2 class="titlepad">Subcategories</h2>

            <input type='checkbox' name="subcategory[]" value="Accounting" id="Accounting"> Accounting</input><br>
            <input type='checkbox' name="subcategory[]" value="Advice & Help" id="Advice & Help"> Advice & Help</input><br>
            <input type='checkbox' name="subcategory[]" value="ATM" id="ATM"> ATM</input><br>
            <input type='checkbox' name="subcategory[]" value="Bank" id="Bank"> Bank</input><br>
            <input type='checkbox' name="subcategory[]" value="Finacing" id="Financing"> Financing</input><br>
            <input type='checkbox' name="subcategory[]" value="Loan" id="Loan"> Loan</input><br>
            <input type="text" name="subcategory[]" id="OtherBFsubcategory" placeholder="Add own suggestion"></input>
            <!-- <input type='checkbox' name="subcategory[]" value="OtherBFSub" id="OtherBFSub"> Other</input><br> -->

        </div>

        <div class="col-md-6">

            <h2 class="titlepad">Extras</h2>

            <input type='checkbox' name="extras[]" value="Appointment" id="Appointment"> Appointment</input><br>
            <input type='checkbox' name="extras[]" value="Walk-in" id="Walk-in"> Walk-in</input><br>
            <input type="text" name="subcategory[]" id="OtherBFsubcategory" placeholder="Add own suggestion"></input>


        </div>

    </div>
    <div class="col-md-12 twentyunderpad">

        <div class="col-md-6">

        <h2 class="titlepad">Features</h2>

            <input type='checkbox' name="filters[]" value="Wifi" id="wifi"> Free Wifi</input><br>
            <input type='checkbox' name="filters[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input><br>
            <input type='checkbox' name="filters[]" value="Children friendly" class="childrenfriendly"> Children friendly</input><br>
            <input type='checkbox' name="filters[]" value="Dog friendly" class="dogfriendly"> Dog friendly</input><br>
            <input type='checkbox' name="filters[]" value="Bike friendly" class="bikefriendly"> Bike friendly</input><br>
            <input type='checkbox' name="filters[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input><br>
            <input type='checkbox' name="filters[]" value="Female toilet" class="femaletoilet"> Female toilet</input><br>
            <input type='checkbox' name="filters[]" value="Male toilet" class="maletoilet"> Male toilet</input><br> 

        </div>

    </div>

</div>