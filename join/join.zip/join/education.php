<div style='display:none;' id='educationfilter'>

    <div class="col-md-12 twentyunderpad">

        <div class="col-md-6">

            <h2 class="titlepad">Subcategories</h2>

            <input type='checkbox' name="subcategory[]" value="Childcare" id="Childcare"> Childcare</input><br>
            <input type='checkbox' name="subcategory[]" value="Early childhood" id="Early childhood"> Early childhood</input><br>
            <input type='checkbox' name="subcategory[]" value="Library" id="Library"> Library</input><br>
            <input type='checkbox' name="subcategory[]" value="Primary" id="Primary"> Primary</input><br>
            <input type='checkbox' name="subcategory[]" value="College" id="College"> College</input><br>
            <input type='checkbox' name="subcategory[]" value="Tertiary" id="Tertiary"> Tertiary</input><br>
            <input type="text" name="subcategory[]" id="OtherEdsubcategory" placeholder="Add own suggestion"></input>
            <!-- <input type='checkbox' name="subcategory[]" value="OtherEdSub" id="OtherEdSub"> Other</input><br> -->

        </div>

        <div class="col-md-6">

            <h2 class="titlepad">Features</h2>

            <input type='checkbox' name="filters[]" value="Wifi" id="wifi"> Free Wifi</input><br>
            <input type='checkbox' name="filters[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input><br>
            <input type='checkbox' name="filters[]" value="Children friendly" class="childrenfriendly"> Children friendly</input><br>
            <input type='checkbox' name="filters[]" value="Dog friendly" class="dogfriendly"> Dog friendly</input><br>
            <input type='checkbox' name="filters[]" value="Bike friendly" class="bikefriendly"> Bike friendly</input><br>
            <input type='checkbox' name="filters[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input><br>
            <input type='checkbox' name="filters[]" value="Female toilet" class="femaletoilet"> Female toilet</input><br>
            <input type='checkbox' name="filters[]" value="Male toilet" class="maletoilet"> Male toilet</input><br> 

        </div>

    </div>

</div>