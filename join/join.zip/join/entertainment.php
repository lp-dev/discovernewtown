<div style='display:none;' id='entertainmentfilter'>

    <div class="col-md-12">

        <div class="col-md-6">

            <h2 class="titlepad">Subcategories</h2>

            <input type='checkbox' name="subcategory[]" value="Attraction" id="Attraction"> Attraction</input><br>
            <input type='checkbox' name="subcategory[]" value="Biking" id="Biking"> Biking</input><br>
            <input type='checkbox' name="subcategory[]" value="Event" id="Event"> Event</input><br>
            <input type='checkbox' name="subcategory[]" value="Music" id=""> Music</input><br>
            <input type='checkbox' name="subcategory[]" value="Park" id="Park"> Park</input><br>
            <input type='checkbox' name="subcategory[]" value="Performance" id="Performance"> Performance</input><br>
            <input type='checkbox' name="subcategory[]" value="Sport" id="Sport"> Sport</input><br>
            <input type='checkbox' name="subcategory[]" value="Walkways" id="Walkways"> Walkways</input><br>
            <input type='checkbox' name="subcategory[]" value="Venue" id="Venue"> Venue</input><br>
            <input type='checkbox' name="subcategory[]" value="Zoo" id="Zoo"> Zoo</input><br>
            <input type="text" name="subcategory[]" id="OtherEnsubcategory" placeholder="Add own suggestion"></input>
            <!-- <input type='checkbox' name="subcategory[]" value="OtherEnSub" id="OtherEnSub"> Other</input><br> -->

        </div>

        <div class="col-md-6">

            <h2 class="titlepad">Type</h2>

            <input type='checkbox' name="type[]" value="Public holiday" id="Public holiday"> Public holiday</input><br>
            <input type='checkbox' name="type[]" value="Weekday" id="Weekday"> Weekday</input><br>
            <input type='checkbox' name="type[]" value="Weekend" id="Weekend"> Weekend</input><br>
            <input type="text" name="type[]" id="OtherEntype" placeholder="Add own suggestion"></input>

        </div>

    </div>
    <div class="col-md-12 twentyunderpad">

        <div class="col-md-6">

            <h2 class="titlepad">Cost</h2>

            <input type='checkbox' name="cost[]" value="Cost" id="Cost"> Cost</input><br>
            <input type='checkbox' name="cost[]" value="Free" id="Free"> Free</input><br>
            <input type="text" name="cost[]" id="OtherEncost" placeholder="Add own suggestion"></input>

        </div>

        <div class="col-md-6">

            <h2 class="titlepad">Features</h2>

            <input type='checkbox' name="filters[]" value="Wifi" id="wifi"> Free Wifi</input><br>
            <input type='checkbox' name="filters[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input><br>
            <input type='checkbox' name="filters[]" value="Children friendly" class="childrenfriendly"> Children friendly</input><br>
            <input type='checkbox' name="filters[]" value="Dog friendly" class="dogfriendly"> Dog friendly</input><br>
            <input type='checkbox' name="filters[]" value="Bike friendly" class="bikefriendly"> Bike friendly</input><br>
            <input type='checkbox' name="filters[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input><br>
            <input type='checkbox' name="filters[]" value="Female toilet" class="femaletoilet"> Female toilet</input><br>
            <input type='checkbox' name="filters[]" value="Male toilet" class="maletoilet"> Male toilet</input><br> 

        </div>

    </div>

</div>