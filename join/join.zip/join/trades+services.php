<div style='display:none;' id='tradesservicesfilter'>

    <div class="col-md-12 twentyunderpad">

        <div class="col-md-6">

            <h2 class="titlepad">Subcategories</h2>

            <input type='checkbox' name="subcategory[]" value="Bicycle mechanic" id="Bicycle mechanic"> Bicycle mechanic</input><br>
            <input type='checkbox' name="subcategory[]" value="Builder" id="Builder"> Builder</input><br>
            <input type='checkbox' name="subcategory[]" value="Carpenter" id="Carpenter"> Carpenter</input><br>
            <input type='checkbox' name="subcategory[]" value="Citizens Advice Bureau" id="Citizens Advice Bureau"> Citizens Advice Bureau</input><br>
            <input type='checkbox' name="subcategory[]" value="Cleaning" id="Cleaning"> Cleaning</input><br>
            <input type='checkbox' name="subcategory[]" value="Design" id="Design"> Design</input><br>
            <input type='checkbox' name="subcategory[]" value="Electrical" id="Electrical"> Electrical</input><br>
            <input type='checkbox' name="subcategory[]" value="Florist" id="Florist"> Florist</input><br>
            <input type='checkbox' name="subcategory[]" value="Glass" id="Glass"> Glass</input><br>
            <input type='checkbox' name="subcategory[]" value="Government" id="Government"> Government</input><br>
            <input type='checkbox' name="subcategory[]" value="Hire" id="Hire"> Hire</input><br>
            <input type='checkbox' name="subcategory[]" value="Laundry Drycleaners" id="LaundryDrycleaners"> Laundry / Drycleaners</input><br>
            <input type='checkbox' name="subcategory[]" value="Lawyer" id="Lawyer"> Lawyer</input><br>
            <input type='checkbox' name="subcategory[]" value="Maintenance Property" id="Maintenance Property"> Maintenance / Property</input><br>
            <input type='checkbox' name="subcategory[]" value="Painters Decorators" id="Painters Decorators"> Painters / Decorators</input><br>
            <input type='checkbox' name="subcategory[]" value="Pet care" id="Pet care"> Pet care</input><br>
            <input type='checkbox' name="subcategory[]" value="Photography" id="Photography"> Photography</input><br>
            <input type='checkbox' name="subcategory[]" value="Plumbing" id="Plumbing"> Plumbing</input><br>
            <input type='checkbox' name="subcategory[]" value="Post" id="Post"> Post</input><br>
            <input type='checkbox' name="subcategory[]" value="Printing" id="Printing"> Printing</input><br>
            <input type='checkbox' name="subcategory[]" value="Property" id="Property"> Property</input><br>
            <input type='checkbox' name="subcategory[]" value="Property services" id="Property services"> Property services</input><br>
            <input type='checkbox' name="subcategory[]" value="Public service" id="Public service"> Public service</input><br>
            <input type='checkbox' name="subcategory[]" value="RealEstate" id="RealEstate"> Real Estate</input><br>
            <input type='checkbox' name="subcategory[]" value="Roofing" id="Roofing"> Roofing</input><br>
            <input type='checkbox' name="subcategory[]" value="Storage" id="Storage"> Storage</input><br>
            <input type='checkbox' name="subcategory[]" value="Travel agency" id="Travel agency"> Travel agency</input><br>
            <input type="text" name="subcategory[]" id="OtherTSsubcategory" placeholder="Add own suggestion"></input>
            <!-- <input type='checkbox' name="subcategory[]" value="OtherTSSub" id="OtherTSSub"> Other</input><br> -->

        </div>

        <div class="col-md-6">

            <h2 class="titlepad">Features</h2>

            <input type='checkbox' name="filters[]" value="Wifi" id="wifi"> Free Wifi</input><br>
            <input type='checkbox' name="filters[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input><br>
            <input type='checkbox' name="filters[]" value="Children friendly" class="childrenfriendly"> Children friendly</input><br>
            <input type='checkbox' name="filters[]" value="Dog friendly" class="dogfriendly"> Dog friendly</input><br>
            <input type='checkbox' name="filters[]" value="Bike friendly" class="bikefriendly"> Bike friendly</input><br>
            <input type='checkbox' name="filters[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input><br>
            <input type='checkbox' name="filters[]" value="Female toilet" class="femaletoilet"> Female toilet</input><br>
            <input type='checkbox' name="filters[]" value="Male toilet" class="maletoilet"> Male toilet</input><br> 

        </div>

    </div>

</div>