<?php include 'header.php'; ?>

    <div class="container conmarg">

<?php include 'menu/main.php'; ?>

		<div class="col-md-9" id="col2">

			<h1>Search results</h1><hr>

				<?php

				// $db = new mysqli('localhost', 'besthai1_dnuser', 'dn_15Connect', 'besthai1_dnsearch');
				// //$db = new mysqli('localhost', 'root', '', 'besthai1_dnsearch');

				// if($db->connect_errno > 0){
				//     die('Unable to connect to database [' . $db->connect_error . ']');
				// }

				// $searchterm = $db->real_escape_string($_POST["searchterm"]);

				// $sql = "SELECT * FROM `dnlistings` WHERE (
				// 	`listing` LIKE '%$searchterm%'
				// 	OR `listing` LIKE '% $searchterm %'
				// 	OR `listing` LIKE '% $searchterm'
				// 	OR `listing` LIKE '$searchterm %'
				// 	OR `listing` LIKE '%$searchterm');";

				// if(!$result = $db->query($sql)){
				//     die('Error, that\'s not good!<br> Please let us know and quote this:<br><br> [' . $db->error . ']');
				// } 

				// // while($row = $result->fetch_assoc()){
				// // 	echo "<b>" .$row ['name'] . " - </b>" .$row ['about'] . " <i>" . $row['tags'] . "</i><div class=\"feedspacer\"></div>" ;
				// // }

				// while($row = $result->fetch_assoc()){
				// 	echo $row ['listing'] ;
				// }


				// $result = $db->query("SELECT COUNT(*) AS totalentries FROM `dnlistings` WHERE '$searchterm' = !true;");
				// $row = $result->fetch_assoc();
				// //echo "<br><hr>".$row['totalentries']." entries in database (<b>FIX THIS FEATURE LATER - # RESULTS</b>)";

				// $result->close();

				// $db->close();

				?>

				<?php

					//$db = new mysqli('localhost', 'besthai1_dnuser', 'dn_15Connect', 'besthai1_dnlistings');
			        //$db = new mysqli('localhost', 'root', '', 'besthai1_dnlistings');
					
					include 'connect.php';

			        if($db->connect_errno > 0){
			            die('Unable to connect to database [' . $db->connect_error . ']');
			        }

			        //$searchterm = "active";
			        $active = "yes";
			        $premium = "yes";
			        //$category = "Food+Drink";

			        $searchterm = $db->real_escape_string($_POST["searchterm"]);

					// $sql = "SELECT * FROM `dnlistings` 
					// WHERE (`Active` LIKE '%$active%' AND `Premium` LIKE '%$premium%' AND `SDescription` LIKE '%$searchterm%'
					// OR `SDescription` LIKE '% $searchterm %'
					// OR `SDescription` LIKE '% $searchterm'
					// OR `SDescription` LIKE '$searchterm %'
					// OR `SDescription` LIKE '%$searchterm');";

					//$sql = "SELECT * FROM `dnlistings` WHERE ( `Active` LIKE '%$active%' AND `Premium` LIKE '%$premium%' AND `Name` LIKE '%$searchterm%' OR `SDescription` LIKE '%$searchterm%' OR `Address` LIKE '%$searchterm%');";
					//$sql = "SELECT * FROM `dnlistings` WHERE ( `Active` LIKE '%$active%' AND `Premium` LIKE '%$premium%' AND `Name` LIKE '%$searchterm%' OR `SDescription` LIKE '%$searchterm%');";
					$sql = "SELECT * FROM `dnlistings` WHERE ( `Active` LIKE '%$active%' AND `Premium` LIKE '%$premium%' AND `Summary` LIKE '%$searchterm%');";

			        // $sql = "SELECT * FROM `dnlistings` WHERE (
			        //     `Active` LIKE '%$searchterm%'
			        //     OR `Active` LIKE '% $searchterm %'
			        //     OR `Active` LIKE '% $searchterm'
			        //     OR `Active` LIKE '$searchterm %'
			        //     OR `Active` LIKE '%$searchterm');";
					
					// $sql = "SELECT * FROM `dnlistings` WHERE (
			 		// `Active` LIKE '%$active%'
			 		// AND `Premium` LIKE '%$premium%' AND `Category` LIKE '%$category%');";

			        if(!$result = $db->query($sql)){
			            die('Error, that\'s not good!<br> Please let us know and quote this:<br><br> [' . $db->error . ']');
			        } 

			        // while($row = $result->fetch_assoc()){
			        //  echo "<b>" .$row ['name'] . " - </b>" .$row ['about'] . " <i>" . $row['tags'] . "</i><div class=\"feedspacer\"></div>" ;
			        // }

			        while($row = $result->fetch_assoc()){
			            // echo "<p>" . $row ['Business'] . " </p><br/>";


					    echo "
					<div class=\"col-md-12 listingpadding\">
						<div class=\"col-md-4 listingpadding middlebtmpad\">
			  				<a href=\"" . $row ['Page'] . "\" target=\"_blank\"><img src=\"" . $row ['Photo'] . ".jpg\" class=\"img-responsive listimg\" alt=\"premiumlisting\"></a>
				  		</div>
				  		<div class=\"col-md-4 middlebtmpad\">
				  			<h4 class=\"list-group-item-heading\">" . $row ['Name'] . "</h4>
							<p class=\"list-group-item-text\">" . $row ['Address'] . "</p>
							<p class=\"list-group-item-text\">" . $row ['Phone'] . "</p>
				  		</div>
				  		<div class=\"col-md-4 middlebtmpad\">
				  			<p class=\"list-group-item-text\">" . $row ['SDescription'] . "</p>
				  			<!-- <button type=\"button\" class=\"btn btn-default tenpad listingbtn\" data-toggle=\"modal\" data-target=\"#featuresmodal\"><img class=\"listingimg\" src=\"img/btns/features.png\" alt=\"features\">View features</button> -->
				  			<a href=\"" . $row ['Page'] . "\"><button type=\"button\" class=\"btn btn-default tenpad listingbtn\"><img class=\"listingimg\" src=\"img/btns/webpage.png\" alt=\"webpage\">More info</button></a>
				  		</div>
					</div>
					";

			        }

			        $result = $db->query("SELECT COUNT(*) AS totalentries FROM `dnlistings` WHERE '$active' = !true;");
			        $row = $result->fetch_assoc();
			        //echo "<br><hr>".$row['totalentries']." entries in database (<b>FIX THIS FEATURE LATER - # RESULTS</b>)";

			        $result->close();

			        $db->close();

				?>  

				<?php

					//$db = new mysqli('localhost', 'besthai1_dnuser', 'dn_15Connect', 'besthai1_dnlistings');
			        //$db = new mysqli('localhost', 'root', '', 'besthai1_dnlistings');
					
					include 'connect.php';

			        if($db->connect_errno > 0){
			            die('Unable to connect to database [' . $db->connect_error . ']');
			        }

			        //$searchterm = "active";
			        $active = "yes";
			        $premium = "no";
			        //$category = "Food+Drink";

			        $searchterm = $db->real_escape_string($_POST["searchterm"]);

					// $sql2 = "SELECT * FROM `dnlistings` 
					// WHERE (`SDescription` LIKE '%$searchterm%'
					// OR `SDescription` LIKE '% $searchterm %'
					// OR `SDescription` LIKE '% $searchterm'
					// OR `SDescription` LIKE '$searchterm %'
					// OR `SDescription` LIKE '%$searchterm');";

					//$sql2 = "SELECT * FROM `dnlistings` WHERE ( `Active` LIKE '%$active%' AND `Premium` LIKE '%$premium%' AND `Name` LIKE '%$searchterm%' OR `SDescription` LIKE '%$searchterm%');";
					$sql2 = "SELECT * FROM `dnlistings` WHERE ( `Active` LIKE '%$active%' AND `Premium` LIKE '%$premium%' AND `Summary` LIKE '%$searchterm%');";


			        // $sql = "SELECT * FROM `dnlistings` WHERE (
			        //     `Active` LIKE '%$searchterm%'
			        //     OR `Active` LIKE '% $searchterm %'
			        //     OR `Active` LIKE '% $searchterm'
			        //     OR `Active` LIKE '$searchterm %'
			        //     OR `Active` LIKE '%$searchterm');";
					
					// $sql = "SELECT * FROM `dnlistings` WHERE (
			  		// `Active` LIKE '%$active%'
			  		// AND `Premium` LIKE '%$premium%' AND `Category` LIKE '%$category%');";

			        if(!$result = $db->query($sql2)){
			            die('Error, that\'s not good!<br> Please let us know and quote this:<br><br> [' . $db->error . ']');
			        } 

			        // while($row = $result->fetch_assoc()){
			        //  echo "<b>" .$row ['name'] . " - </b>" .$row ['about'] . " <i>" . $row['tags'] . "</i><div class=\"feedspacer\"></div>" ;
			        // }

			        while($row = $result->fetch_assoc()){
			            // echo "<p>" . $row ['Business'] . " </p><br/>";


					    echo "
					<div class=\"col-md-12 listingpadding\">
						<div class=\"col-md-4 listingpadding middlebtmpad\">
			  				<a href=\"signup.php\"><img src=\"img/basic/listingimg.jpg\" class=\"img-responsive listimg\" alt=\"basiclisting\"></a>
				  		</div>
				  		<div class=\"col-md-4 middlebtmpad\">
							<h4 class=\"list-group-item-heading\">" . $row ['Name'] . "</h4>
							<p class=\"list-group-item-text\">" . $row ['Address'] . "</p>
							<p class=\"list-group-item-text\">" . $row ['Phone'] . "</p>
				  		</div>
				  		<div class=\"col-md-4 middlebtmpad\">
				  			<button type=\"button\" class=\"btn btn-default tenpad listingbtn\"><img class=\"listingimg\" src=\"img/btns/nowebpage.png\" alt=\"nowebpage\">More info</button>
				  		</div>
					</div>
					";

			        }

			        $result = $db->query("SELECT COUNT(*) AS totalentries FROM `dnlistings` WHERE '$active' = !true;");
			        $row = $result->fetch_assoc();
			        //echo "<br><hr>".$row['totalentries']." entries in database (<b>FIX THIS FEATURE LATER - # RESULTS</b>)";

			        $result->close();

			        $db->close();

				?>  

		</div>	

	</div>

<?php include 'footer.php'; ?>

  </body>
</html>