<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <!--<meta http-equiv="X-UA-Compatible" content="IE=edge">-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Discover Newtown.</title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <link href="css/main.css" rel="stylesheet">
    <script src="js/script.js"></script>
  </head>
  <body>
    <nav class="navbar navbar-default navbar-static-top">
        <div class="container">

            <div class="col-md-3">
                <div>
                    <a href="signup.php"><button type="button" class="btn btn-default headerelement stretch"><img class="joinimg" src="img/btns/join.png" alt="join">FREE sign up.</img></button></a>
                </div>
            </div>

            <div class="col-md-6">
                <div>
                    <a href="index.php"><img src="img/home-logo.png" class="img-responsive headerelement" alt="Home logo image"></img></a>
                </div>
            </div>

            <div class="col-md-3">        

                <form class="input-group headerelement" role="search" method="POST" action="search.php">
                  <input type="text" class="form-control" name="searchterm" id="searchterm" placeholder="Search all listings">
                  <span class="input-group-btn">
                    <button class="btn btn-default" type="submit" value="Search">Search</button>
                  </span>
                </form>

            </div>

        </div>

    </nav>