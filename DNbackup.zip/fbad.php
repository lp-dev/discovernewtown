
        <button type="button" class="btn btn-default headerelement stretch showfb"><img class="joinimg " src="img/btns/menu.png" alt="Facebook module">Facebook page</img></button>

        <div class="panel panel-default fbmenu">

	        <div id="fb-root">
	    	</div>
	    	
			<script>
			(function(d, s, id) {
			  var js, fjs = d.getElementsByTagName(s)[0];
			  if (d.getElementById(id)) return;
			  js = d.createElement(s); js.id = id;
			  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.4";
			  fjs.parentNode.insertBefore(js, fjs);
			}(document, 'script', 'facebook-jssdk'));
			</script>

		  	<!-- <div class="fb-page" data-href="https://www.facebook.com/BestHairStyle" data-tabs="timeline" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false">
		  		<div class="fb-xfbml-parse-ignore">
		  			<blockquote cite="https://www.facebook.com/BestHairStyle"><a href="https://www.facebook.com/BestHairStyle">Best Hair Style - Amadeus Hair and Beauty Salon</a></blockquote>
		  		</div>
		  	</div> -->

			<!-- <div id="facebook-posts"> -->
				<div class="fb-page facebook-posts-inner" data-href="https://www.facebook.com/newtownwellington" data-height="600" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false" data-show-posts="true"><div class="fb-xfbml-parse-ignore"></div></div>
			<!-- </div> -->
          
        </div>

        <img src="img/home-ad.jpg" class="img-responsive stretch twentypad" alt="Home ad image">


    </div>

	