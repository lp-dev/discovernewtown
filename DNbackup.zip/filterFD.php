<?php include 'header.php'; ?>

    <div class="container conmarg">
	  
	  <div class="col-md-3 middlebtmpad" id="col1">
        <a  href="food+drink.php"><button type="button" class="btn btn-default headerelement stretch"><img class="filterimg" src="img/menu/f.png" alt="filter"></img>Food & Drink</button></a>
      </div>

	  <div class="col-md-6 middlebtmpad" id="col2">

	  	<h1>Filter listings</h1><hr>

		<form id="filterform" role="search" method="POST" action="resultsFD.php">

				<h4>Please choose any filters to apply.</h4>

				<div id='fooddrinkfilter'>
					
					<h2 class="titlepad">Subcategories.</h2>
				    <!-- <input type='checkbox' name="foodrinksubcategory[]" value="Bakery" id="bakery">Bakery</input> -->
				    <input type='checkbox' name="filters[]" value="Bakery" id="bakery">Bakery</input>
				    <input type='checkbox' name="filters[]" value="Bar" id="bar">Bar</input>
				    <input type='checkbox' name="filters[]" value="Cafe" id="cafe">Cafe</input>
				    <input type='checkbox' name="filters[]" value="Dairy" id="dairy">Dairy</input>
				    <input type='checkbox' name="filters[]" value="Restaurant" id="restaurant">Restaurant</input>
				    <input type='checkbox' name="filters[]" value="Supermarket" id="supermarket">Supermarket</input>
				    <input type='checkbox' name="filters[]" value="Takeaway" id="takeaway">Takeaway</input>
				    <input type='checkbox' name="filters[]" value="Other (food and drink)" id="subotherfood+drink">Other</input>

				    <h2 class="titlepad">Additional filter options for your listing.</h2>

				    <p>Type:</p>
				    <!-- <input type="text" class="form-control fieldpad" name="type[]" placeholder="Type your own options. Please seperate each option with a comma." id=""></input> -->
				    <input type='checkbox' name="filters[]" value="American" id="american">American</input>
				    <input type='checkbox' name="filters[]" value="Chinese" id="chinese">Chinese</input>
				    <input type='checkbox' name="filters[]" value="Italian" id="italian">Italian</input>
				    <input type='checkbox' name="filters[]" value="Indian" id="indian">Indian</input>
				    <input type='checkbox' name="filters[]" value="French" id="french">French</input>
				    <input type='checkbox' name="filters[]" value="Japanese" id="japanese">Japanese</input>
				    <input type='checkbox' name="filters[]" value="Mexican" id="mexican">Mexican</input>
				    <input type='checkbox' name="filters[]" value="New Zealand" id="newzealand">New Zealand</input>
				    <input type='checkbox' name="filters[]" value="Thai" id="thai">Thai</input>
				    <input type='checkbox' name="filters[]" value="Other" id="otherfood+drink">Other</input>
				    <!-- <input type='checkbox' name="type[]" value=" " id="allfood+drink">All</input><hr> -->

					<p class="checkpad">Cost:</p>
				    <input type='checkbox' name="filters[]" value="Under $15" id="under15">Under $15</input>
				    <input type='checkbox' name="filters[]" value="Under $25" id="under25">Under $25</input>
				    <input type='checkbox' name="filters[]" value="Under $30" id="under30">Under $30</input>
				    <input type='checkbox' name="filters[]" value="Under $40" id="under40">Under $40</input>
				    <input type='checkbox' name="filters[]" value="Under $50" id="under50">Under $50</input>

				    <p class="checkpad">Extras:</p>
				    <!-- <input type="text" class="form-control fieldpad" name="extras[]" placeholder="Type your own options. Please seperate each option with a comma." id=""></input> -->
				    <input type='checkbox' name="filters[]" value="B.Y.O." id="byo">B.Y.O.</input>
				    <input type='checkbox' name="filters[]" value="Coffee" id="coffee">Coffee</input>
				    <input type='checkbox' name="filters[]" value="Gluten Free" id="glutenfree">Gluten Free</input>
				    <input type='checkbox' name="filters[]" value="Halal" id="halal">Halal</input>
				    <input type='checkbox' name="filters[]" value="Licensed" id="licensed">Licensed</input>
				    <input type='checkbox' name="filters[]" value="Organic" id="organic">Organic</input>
				    <input type='checkbox' name="filters[]" value="Vegan" id="vegan">Vegan</input>
				    <input type='checkbox' name="filters[]" value="Vegetarian" id="vegetarian">Vegetarian</input>

				    <p class="checkpad">Features:</p>
				    <input type='checkbox' name="filters[]" value="Wheelchair friendly" class="wheelchairfriendly">Wheelchair friendly</input>
				    <input type='checkbox' name="filters[]" value="Children friendly" class="childrenfriendly">Children friendly</input>
				    <input type='checkbox' name="filters[]" value="Dog friendly" class="dogfoodfriendly">Dog friendly</input>
				    <input type='checkbox' name="filters[]" value="Bike friendly" class="bikefoodfriendly">Bike friendly</input>
				    <input type='checkbox' name="filters[]" value="Accessible toilet" class="accesibletoilet">Accessible toilet</input>
				    <input type='checkbox' name="filters[]" value="Female toilet" class="femaletoilet">Female toilet</input>
				    <input type='checkbox' name="filters[]" value="Male toilet" class="maletoilet">Male toilet</input>				    

				</div>


				<div class="col-lg-12 fieldbuffer">
					<input type="submit" class="btn btn-default" value="Apply">
					<input type="reset" class="btn btn-default" value="Reset">
				</div>

		</form>

<!-- 		<form class="input-group headerelement" role="search" method="POST" action="resultsfood+drink.php">
              <input type="text" class="form-control" name="searchterm" id="searchterm" placeholder="Search all listings">
              <span class="input-group-btn">
              	<button class="btn btn-default" type="submit" value="Search">Search</button>
              </span>
        </form> -->

	  </div>

	  <div class="col-md-3 middlebtmpad" id="col3">

<?php include 'blank.php'; ?>
		
<?php include 'footer.php'; ?>