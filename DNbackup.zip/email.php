<?php

	mail('contact@discovernewtown.co.nz', 'Website join form', 'Hello');
    // header('Location: ../build/done.php');
            
?>