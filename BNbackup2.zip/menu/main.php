      <div class="col-md-3" id="col1">
        <button type="button" class="btn btn-default headerelement stretch showmenu"><img class="joinimg " src="img/btns/menu.png" alt="category menu">Category menu</img></button>
        <!-- <button type="button" class="btn btn-default headerelement stretch"><img class="menuimgtoggle joinimg" src="img/btns/menu.png" alt="category menu">Menu</img></button>
        <button type="button" class="btn btn-default buttonmenu menutitle showmenu"><img class="menuimgtoggle" src="img/menu/menu.png" alt="category menu">Menu</img></button> -->
        <!-- <div class="panel panel-default catmenu">
            <div class="btn-group-vertical" role="group" aria-label="...">
                <a href="emergency.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/emergency.png" alt="emergency">Emergency</img></button></a>
                <a href="accommodation.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/a.png" alt="A">Accommodation</img></button></a>
                <a href="automotive.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/a.png" alt="A">Automotive</img></button></a>
                <a href="banking+finance.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/b.png" alt="B">Banking & Finance</img></button></a>
                <a href="community.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/c.png" alt="C">Community</img></button></a>
                <a href="computers+it.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/c.png" alt="C">Computers & I.T.</img></button></a>
                <a href="education.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/e.png" alt="E">Education</img></button></a>
                <a href="entertainment.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/e.png" alt="E">Entertainment</img></button></a>
                <a href="food+drink.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/f.png" alt="F">Food & Drink</img></button></a>
                <a href="health+beauty.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/h.png" alt="H">Health & Beauty</img></button></a>
                <a href="medical.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/m.png" alt="M">Medical</img></button></a>
                <a href="retail+shopping.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/r.png" alt="R">Retail & Shopping</img></button></a>
                <a href="sports+recreation.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/s.png" alt="S">Sports & Recreation</img></button></a>
                <a href="trades+services.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/t.png" alt="T">Trades & Services</img></button></a>
                <a href="other.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/other.png" alt="...">Other</img></button></a>
            </div>
        </div> -->
        <div class="panel panel-default catmenu hidemenu">
            <div class="btn-group-vertical" role="group" aria-label="...">
                <a href="emergency.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/emergency.png" alt="emergency">Emergency</img></button></a>
                <a href="accommodation.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/a.png" alt="A">Accommodation</img></button></a>
                <a href="automotive.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/a.png" alt="A">Automotive</img></button></a>
                <a href="banking+finance.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/b.png" alt="B">Banking & Finance</img></button></a>
                <a href="community.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/c.png" alt="C">Community</img></button></a>
                <a href="computers+it.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/c.png" alt="C">Computers & I.T.</img></button></a>
                <a href="education.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/e.png" alt="E">Education</img></button></a>
                <a href="entertainment.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/e.png" alt="E">Entertainment</img></button></a>
                <a href="food+drink.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/f.png" alt="F">Food & Drink</img></button></a>
                <a href="health+beauty.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/h.png" alt="H">Health & Beauty</img></button></a>
                <a href="medical.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/m.png" alt="M">Medical</img></button></a>
                <a href="retail+shopping.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/r.png" alt="R">Retail & Shopping</img></button></a>
                <a href="sports+recreation.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/s.png" alt="S">Sports & Recreation</img></button></a>
                <a href="trades+services.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/t.png" alt="T">Trades & Services</img></button></a>
                <a href="other.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/other.png" alt="...">Other</img></button></a>
            </div>
        </div>
      </div>