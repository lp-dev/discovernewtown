
        <button type="button" class="btn btn-default headerelement stretch showfb showlinks"><img class="joinimg " src="img/btns/menu.png" alt="Facebook module">Helpful links</img></button>

        <!-- <div class="panel panel-default fbmenu">

	        <div id="fb-root">
	    	</div> -->
	    	
			<script>
			// (function(d, s, id) {
			//   var js, fjs = d.getElementsByTagName(s)[0];
			//   if (d.getElementById(id)) return;
			//   js = d.createElement(s); js.id = id;
			//   js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.4";
			//   fjs.parentNode.insertBefore(js, fjs);
			// }(document, 'script', 'facebook-jssdk'));
			</script>

		  	<!-- <div class="fb-page" data-href="https://www.facebook.com/BestHairStyle" data-tabs="timeline" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false">
		  		<div class="fb-xfbml-parse-ignore">
		  			<blockquote cite="https://www.facebook.com/BestHairStyle"><a href="https://www.facebook.com/BestHairStyle">Best Hair Style - Amadeus Hair and Beauty Salon</a></blockquote>
		  		</div>
		  	</div> -->

			<!-- <div id="facebook-posts"> -->


				<!-- <div class="fb-page facebook-posts-inner" data-href="https://www.facebook.com/newtownwellington" data-height="600" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false" data-show-posts="true"><div class="fb-xfbml-parse-ignore"></div></div> -->
			

			<!-- </div> -->
          
        <!-- </div> -->

        <div class="linksmenu hidemenu">

	        <a href="signup.php" target="_blank"><button type="button" class="btn btn-default headerelement stretch"><img class="joinimg" src="img/btns/join.png" alt="join">Sign up here.</img></button></a>
	        <a href="http://www.discovernewtown.co.nz/forum" target="_blank"><button type="button" class="btn btn-default headerelement stretch"><img class="joinimg" src="img/btns/join.png" alt="join">View noticeboard.</img></button></a>
	        <a href="https://www.facebook.com/newtownwellington" target="_blank"><button type="button" class="btn btn-default headerelement stretch"><img class="joinimg" src="img/btns/join.png" alt="join">View Facebook.</img></button></a>
	   
	    </div>

        <img src="img/home-ad.jpg" class="img-responsive stretch twentypad" alt="Home ad image">


    </div>

	