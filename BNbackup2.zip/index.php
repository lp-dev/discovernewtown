<?php include 'header.php'; ?>

<?php include 'alertemail.php'; ?>

    <div class="container conmarg">

<?php include 'menu/main.php'; ?>

		<div class="col-md-6 middlebtmpad" id="col2">

			<h1>Welcome to Discover Newtown</h1><hr>

			<!-- <img src="img/home-image.jpg" class="img-responsive" alt="Home banner image"> -->
			<div id="carouselcommunity" class="carousel slide" data-ride="carousel">
			  <!-- Indicators -->
			  <ol class="carousel-indicators">
			    <li data-target="#carouselcommunity" data-slide-to="0" class="active"></li>
			    <li data-target="#carouselcommunity" data-slide-to="1"></li>
			    <li data-target="#carouselcommunity" data-slide-to="2"></li>
			  </ol>
			  <div class="carousel-inner" role="listbox">
			    <div class="item active">
			      <img src="notices/slide1.jpg" alt="slide1">
			      <div class="carousel-caption">
				    <h4>Caption</h4>
				    <p>...</p>
				  </div>
			    </div>
			    <div class="item">
			      <img src="notices/slide2.jpg" alt="slide2">
			      <div class="carousel-caption">
				    <p>...</p>
				  </div>
			    </div>
			     <div class="item">
			      <img src="notices/slide3.jpg" alt="slide3">
			      <div class="carousel-caption">
				    <h4>...</h4>
				  </div>
			    </div>
			  </div>
			  <a class="left carousel-control" href="#carouselcommunity" role="button" data-slide="prev">
			    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
			    <span class="sr-only">Previous</span>
			  </a>
			  <a class="right carousel-control" href="#carouselcommunity" role="button" data-slide="next">
			    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
			    <span class="sr-only">Next</span>
			  </a>
			</div><br>

			<h3 class="titlepad">Welcome to our Newtown community website.</h3>
			<div id="break"></div><br>
			<p>Whether you are a resident, business owner, community organiser, local club or a visitor we can help you discover what Newtown has to offer. We have information and resources at hand for you to share and make contact with others in the Newtown Community.</p>
			<p>Take advantage of our free listing service in the classifieds. Also check out our notice boards to find out what is happening in Newtown and share with others.</p>
			<!-- <a href="signup.php"><h4>Click here to make your free listing.</h4></a>
			<a href="http://www.discovernewtown.co.nz/forum" target="_blank"><h4>Click here to check out the noticeboards.</h4></a>
			 -->

			<p>Do you have anything you would like to suggest? We appreciate ideas to improve what we can offer to our Newtown community.</p>

            
		</div>

		<div class="col-md-3 middlebtmpad" id="col3">

<?php include 'fbad.php'; ?>

<!-- NEWSLETTER -- >

		<!-- <div class="modal fade" id="newslettermodal" tabindex="-1" role="dialog" aria-labelledby="newslettermodallabel">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h3 class="modal-title" id="newslettermodallabel">Welcome to Discover Newtown.</h3>
					</div>
					<div class="modal-body">
						<h4>Would you like to subscribe to our newsletter?</h4>
						<form class="form-horizontal">
							<div class="form-group">

							   	<div class="col-sm-12 newsletterinput">
							    	<input type="text" class="form-control" id="exampleInputName2" placeholder="First & Last names">
							    </div>
								<div class="col-sm-12 newsletterinput">
									<input type="email" class="form-control" id="inputEmail3" placeholder="Email address">
								</div>
							</div>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Dismiss</button>
						<button type="button" class="btn btn-primary">Subscribe</button>
					</div>
				</div>
			</div>
		</div> -->
		
<?php include 'footer.php'; ?>