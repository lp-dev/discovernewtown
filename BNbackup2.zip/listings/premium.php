<?php

	echo "
		<div class=\"col-md-12 listingpadding\">
			<div class=\"col-md-4 listingpadding middlebtmpad\">
				<a href=\"" . $row ['Page'] . "\" target=\"_blank\"><img src=\"" . $row ['Photo'] . "\" class=\"img-responsive listimg\" alt=\"premiumlisting\"></a>
			</div>
			<div class=\"col-md-4 middlebtmpad\">
				<h4 class=\"list-group-item-heading\">" . $row ['Name'] . "</h4>
				<p class=\"list-group-item-text\">" . $row ['Address'] . "</p>
				<p class=\"list-group-item-text\">" . $row ['Phone'] . "</p>
			</div>
			<div class=\"col-md-4 middlebtmpad\">
				<p class=\"list-group-item-text\">" . $row ['SDescription'] . "</p>
				<a href=\"" . $row ['Page'] . "\" target=\"_blank\"><button type=\"button\" class=\"btn btn-default tenpad listingbtn\"><img class=\"listingimg\" src=\"img/btns/webpage.png\" alt=\"webpage\">More info</button></a>
			</div>
		</div>
	";

?>