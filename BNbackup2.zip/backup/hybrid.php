<?php

  echo "
    <div class=\"col-md-12 listingpadding\">
      <div class=\"col-md-4 listingpadding middlebtmpad\">
        <div id=\"carouselpremium\" class=\"carousel slide\" data-ride=\"carousel\">
          <div class=\"carousel-inner\" role=\"listbox\">
            <div class=\"item active\">
              <a href=\"" . $row ['Page'] . "\" target=\"_blank\"><img src=\"" . $row ['Photo'] . "\" class=\"img-responsive listimg\" alt=\"premiumlisting\"></a>
              <div class=\"carousel-caption\">
              </div>
            </div>
            <div class=\"item\">
              <div class=\"google-maps-listing\">
                <iframe src=\"" . $row ['Map'] . "\" width=\"300\" height=\"300\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class=\"col-md-4 middlebtmpad\">
        <h4 class=\"list-group-item-heading\">" . $row ['Name'] . "</h4>
        <p class=\"list-group-item-text\">" . $row ['Address'] . "</p>
        <p class=\"list-group-item-text\">" . $row ['Phone'] . "</p>
        <p class=\"list-group-item-text\">" . $row ['Email'] . "</p>
      </div>
      <div class=\"col-md-4 middlebtmpad\">
        <p class=\"list-group-item-text\">" . $row ['SDescription'] . "</p>
        <a href=\"http://" . $row ['Website'] . "\" target=\"_blank\"><button type=\"button\" class=\"btn btn-default tenpad listingbtn\"><img class=\"listingimg\" src=\"img/btns/webpage.png\" alt=\"webpage\">View website</button></a>
        <a href=\"https://" . $row ['Facebook'] . "\" target=\"_blank\"><button type=\"button\" class=\"btn btn-default tenpad listingbtn\"><img class=\"listingimg\" src=\"img/btns/webpage.png\" alt=\"webpage\">View Facebook</button></a>
      </div>
    </div>
  ";

?>