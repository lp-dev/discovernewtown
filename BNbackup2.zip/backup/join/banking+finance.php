				<div style='display:none;' id='bankingfinancefilter'>
					<h2 class="titlepad">Subcategories.</h2>
					<input type="text" class="form-control" name="subcategory[]" placeholder="Type your own options. Please seperate each option with a comma." id=""></input>
				    <!-- <input type='checkbox' name="subcategory[]" value="Not applicable" class="notapplicable">Not applicable</input> -->
				    
				    <h2 class="titlepad">Additional filter options for your listing.</h2>

				    <p>Type:</p>
				    <input type="text" class="form-control fieldpad" name="type[]" placeholder="Type your own options. Please seperate each option with a comma." id=""></input>
				    <!-- <input type='checkbox' name="type[]" value="Not applicable" class="notapplicable">Not applicable</input> -->

					<p>Cost:</p>
					<input type="text" class="form-control fieldpad" name="cost[]" placeholder="Type your own options. Please seperate each option with a comma." id=""></input>
				    <!-- <input type='checkbox' name="cost[]" value="Not applicable" class="notapplicable">Not applicable</input> -->

				    <p>Extras:</p>
				    <input type="text" class="form-control fieldpad" name="extras[]" placeholder="Type your own options. Please seperate each option with a comma." id=""></input>
				    <!-- <input type='checkbox' name="extras[]" value="Not applicable" class="notapplicable">Not applicable</input> -->

				    <p>Features:</p>
				    <input type='checkbox' name="features[]" value="Wheelchair friendly" class="wheelchairfriendly check">Wheelchair friendly</input>
				    <input type='checkbox' name="features[]" value="Children friendly" class="childrenfriendly">Children friendly</input>
				    <input type='checkbox' name="features[]" value="Dog friendly" class="dogfoodfriendly">Dog friendly</input>
				    <input type='checkbox' name="features[]" value="Bike friendly" class="bikefoodfriendly">Bike friendly</input>
				    <input type='checkbox' name="features[]" value="Accessible toilet" class="accesibletoilet">Accessible toilet</input>
				    <input type='checkbox' name="features[]" value="Female toilet" class="femaletoilet">Female toilet</input>
				    <input type='checkbox' name="features[]" value="Male toilet" class="maletoilet">Male toilet</input>		
				</div>