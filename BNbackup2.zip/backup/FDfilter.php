<?php include 'header.php'; ?>

    <div class="container conmarg">
	  
	  <div class="col-md-3 middlebtmpad" id="col1">
        <a  href="food+drink.php"><button type="button" class="btn btn-default headerelement stretch"><img class="filterimg" src="img/menu/f.png" alt="filter"></img>Food & Drink</button></a>
      </div>

	  <div class="col-md-6 middlebtmpad" id="col2">

	  	<h1>Filter listings</h1><hr>

		<form id="filterform" role="search" method="POST" action="FDresults.php">

				<h4>Please choose any filters to apply.</h4>

				<!-- <input type='checkbox' name="subcategory" value="Bakery" id="bakery">Bakery</input>
			    <input type='checkbox' name="subcategory[]" value="Bar" id="bar">Bar</input>
			    <input type='checkbox' name="subcategory[]" value="Cafe" id="cafe">Cafe</input>
			    <input type='checkbox' name="subcategory[]" value="Dairy" id="dairy">Dairy</input>
			    <input type='checkbox' name="subcategory" value="Restaurant" id="restaurant">Restaurant</input>
			    <input type='checkbox' name="subcategory[]" value="Supermarket" id="supermarket">Supermarket</input>
			    <input type='checkbox' name="subcategory[]" value="Takeaway" id="takeaway">Takeaway</input>
			    <input type='checkbox' name="subcategory[]" value="Other (food and drink)" id="subotherfood+drink">Other</input> -->

<!-- 				<input type='checkbox' name="category" value="Food+Drink" id="Food+Drink">FD</input>
 -->			    <input type='checkbox' name="category[]" value="Food+Drink" id="Food+Drink">FD[]</input>
<!-- 			    <input type='checkbox' name="category" value="Sports+Recreation" id="Sports+Recreation">SR</input>
 -->			    <input type='checkbox' name="category[]" value="Sports+Recreation" id="Sports+Recreation">SR[]</input>
<!-- 			    <input type='checkbox' name="category" value="Education" id="Education">Ed</input>
 -->			    <input type='checkbox' name="category[]" value="Education" id="Education">Ed[]</input>

				<div class="col-lg-12 fieldbuffer">
					<input type="submit" class="btn btn-default" value="Apply">
					<input type="reset" class="btn btn-default" value="Reset">
				</div>

		</form>

<!-- 		<form class="input-group headerelement" role="search" method="POST" action="resultsfood+drink.php">
              <input type="text" class="form-control" name="searchterm" id="searchterm" placeholder="Search all listings">
              <span class="input-group-btn">
              	<button class="btn btn-default" type="submit" value="Search">Search</button>
              </span>
        </form> -->

	  </div>

	  <div class="col-md-3 middlebtmpad" id="col3">

<?php include 'blank.php'; ?>
		
<?php include 'footer.php'; ?>