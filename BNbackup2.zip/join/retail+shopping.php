<div style='display:none;' id='retailshoppingfilter'>
	
	<h2 class="titlepad">Subcategories.</h2>

    <input type='checkbox' name="subcategory[]" value="BooksMagazines" id="BooksMagazines"> Books / Magazines</input>
    <input type='checkbox' name="subcategory[]" value="Clothing" id="Clothing"> Clothing</input>
    <input type='checkbox' name="subcategory[]" value="Computers" id="Computers"> Computers</input>
    <input type='checkbox' name="subcategory[]" value="Electronics" id="Electronics"> Electronics</input>
    <input type='checkbox' name="subcategory[]" value="Florist" id="Florist"> Florist</input>
    <input type='checkbox' name="subcategory[]" value="Footwear" id="Footwear"> Footwear</input>
    <input type='checkbox' name="subcategory[]" value="Furnishings" id="Furnishings"> Furnishings</input>
    <input type='checkbox' name="subcategory[]" value="GeneralStore" id="GeneralStore"> General store</input>
    <input type='checkbox' name="subcategory[]" value="Hire" id="Hire"> Hire</input>
    <input type='checkbox' name="subcategory[]" value="HobbyCrafts" id="HobbyCrafts"> Hobby / Crafts</input>
    <input type='checkbox' name="subcategory[]" value="Jewellers" id="Jewellers"> Jewellers</input>
    <input type='checkbox' name="subcategory[]" value="Paint" id="Paint"> Paint</input>
    <input type='checkbox' name="subcategory[]" value="Pharmacy" id="Pharmacy"> Pharmacy</input>
    <input type='checkbox' name="subcategory[]" value="Safety" id="Safety"> Safety</input>
    <input type='checkbox' name="subcategory[]" value="SecondhandAntiques" id="SecondhandAntiques"> Secondhand / Antiques</input>
    <input type='checkbox' name="subcategory[]" value="Whiteware" id="Whiteware"> Whiteware</input>
    <input type='checkbox' name="subcategory[]" value="OtherRSSub" id="OtherRSSub"> Other</input>

    <h2 class="titlepad">Additional filter options for your listing.</h2>

    <!-- <p class="checkpad">Type:</p>
    <input type='checkbox' name="type[]" value="" id=""></input>
    <input type='checkbox' name="type[]" value="" id=""></input>
    <input type='checkbox' name="type[]" value="" id=""></input>

	<p class="checkpad">Cost:</p>
	<input type='checkbox' name="cost[]" value="" id=""></input>
	<input type='checkbox' name="cost[]" value="" id=""></input>
	<input type='checkbox' name="cost[]" value="" id=""></input>

    <p class="checkpad">Extras:</p>
    <input type='checkbox' name="extras[]" value="" id=""></input>
    <input type='checkbox' name="extras[]" value="" id=""></input>
    <input type='checkbox' name="extras[]" value="" id=""></input> -->

    <p class="checkpad">Features:</p>
    <input type='checkbox' name="features[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input>
    <input type='checkbox' name="features[]" value="Children friendly" class="childrenfriendly"> Children friendly</input>
    <input type='checkbox' name="features[]" value="Dog friendly" class="dogfoodfriendly"> Dog friendly</input>
    <input type='checkbox' name="features[]" value="Bike friendly" class="bikefoodfriendly"> Bike friendly</input><br>
    <input type='checkbox' name="features[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input>
    <input type='checkbox' name="features[]" value="Female toilet" class="femaletoilet"> Female toilet</input>
    <input type='checkbox' name="features[]" value="Male toilet" class="maletoilet"> Male toilet</input>	

</div>