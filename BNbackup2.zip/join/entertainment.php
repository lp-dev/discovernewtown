<div style='display:none;' id='entertainmentfilter'>
	
	<h2 class="titlepad">Subcategories.</h2>

    <input type='checkbox' name="subcategory[]" value="Attraction" id="Attraction"> Attraction</input>
    <input type='checkbox' name="subcategory[]" value="Biking" id="Biking"> Biking</input>
    <input type='checkbox' name="subcategory[]" value="Festival" id="Festival"> Festival</input>
    <input type='checkbox' name="subcategory[]" value="Music" id=""> Music</input>
    <input type='checkbox' name="subcategory[]" value="Park" id="Park"> Park</input>
    <input type='checkbox' name="subcategory[]" value="Performance" id="Performance"> Performance</input>
    <input type='checkbox' name="subcategory[]" value="Sport" id="Sport"> Sport</input>
    <input type='checkbox' name="subcategory[]" value="Walkways" id="Walkways"> Walkways</input>
    <input type='checkbox' name="subcategory[]" value="Zoo" id="Zoo"> Zoo</input>
    <input type='checkbox' name="subcategory[]" value="OtherEnSub" id="OtherEnSub"> Other</input>

    <h2 class="titlepad">Additional filter options for your listing.</h2>

    <p>Type:</p>
    <input type='checkbox' name="type[]" value="Public holiday" id="Public holiday"> Public holiday</input>
	<input type='checkbox' name="type[]" value="Weekday" id="Weekday"> Weekday</input>
	<input type='checkbox' name="type[]" value="Weekend" id="Weekend"> Weekend</input>
    <input type='checkbox' name="subcategory[]" value="OtherEnType" id="OtherEnType"> Other</input>

	<p>Cost:</p>
	<input type='checkbox' name="cost[]" value="Cost" id="Cost"> Cost</input>
	<input type='checkbox' name="cost[]" value="Free" id="Free"> Free</input>

    <!-- <p>Extras:</p>
    <input type='checkbox' name="extras[]" value="" id=""></input>
    <input type='checkbox' name="extras[]" value="" id=""></input>
    <input type='checkbox' name="extras[]" value="" id=""></input> -->

    <p class="checkpad">Features:</p>
    <input type='checkbox' name="features[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input>
    <input type='checkbox' name="features[]" value="Children friendly" class="childrenfriendly"> Children friendly</input>
    <input type='checkbox' name="features[]" value="Dog friendly" class="dogfoodfriendly"> Dog friendly</input>
    <input type='checkbox' name="features[]" value="Bike friendly" class="bikefoodfriendly"> Bike friendly</input><br>
    <input type='checkbox' name="features[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input>
    <input type='checkbox' name="features[]" value="Female toilet" class="femaletoilet"> Female toilet</input>
    <input type='checkbox' name="features[]" value="Male toilet" class="maletoilet"> Male toilet</input>	

</div>