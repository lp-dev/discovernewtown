<div style='display:none;' id='educationfilter'>
	
	<h2 class="titlepad">Subcategories.</h2>

    <input type='checkbox' name="subcategory[]" value="Childcare" id="Childcare"> Childcare</input>
    <input type='checkbox' name="subcategory[]" value="Early childhood" id="Early childhood"> Early childhood</input>
    <input type='checkbox' name="subcategory[]" value="Library" id="Library"> Library</input>
	<input type='checkbox' name="subcategory[]" value="Primary" id="Primary"> Primary</input>
    <input type='checkbox' name="subcategory[]" value="Tertiary" id="Tertiary"> Tertiary</input>
    <input type='checkbox' name="subcategory[]" value="OtherEdSub" id="OtherEdSub"> Other</input>

    <h2 class="titlepad">Additional filter options for your listing.</h2>

    <!-- <p class="checkpad">Type:</p>
    <input type='checkbox' name="type[]" value="" id=""></input>
    <input type='checkbox' name="type[]" value="" id=""></input>
    <input type='checkbox' name="type[]" value="" id=""></input>

	<p class="checkpad">Cost:</p>
	<input type='checkbox' name="cost[]" value="" id=""></input>
	<input type='checkbox' name="cost[]" value="" id=""></input>
	<input type='checkbox' name="cost[]" value="" id=""></input>

    <p class="checkpad">Extras:</p>
    <input type='checkbox' name="extras[]" value="" id=""></input>
    <input type='checkbox' name="extras[]" value="" id=""></input>
    <input type='checkbox' name="extras[]" value="" id=""></input> -->

    <p class="checkpad">Features:</p>
    <input type='checkbox' name="features[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input>
    <input type='checkbox' name="features[]" value="Children friendly" class="childrenfriendly"> Children friendly</input>
    <input type='checkbox' name="features[]" value="Dog friendly" class="dogfoodfriendly"> Dog friendly</input>
    <input type='checkbox' name="features[]" value="Bike friendly" class="bikefoodfriendly"> Bike friendly</input><br>
    <input type='checkbox' name="features[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input>
    <input type='checkbox' name="features[]" value="Female toilet" class="femaletoilet"> Female toilet</input>
    <input type='checkbox' name="features[]" value="Male toilet" class="maletoilet"> Male toilet</input>

</div>