<div style='display:none;' id='fooddrinkfilter'>
    
	<h2 class="titlepad">Subcategories.</h2>

    <input type='checkbox' name="subcategory[]" value="Bakery" id="bakery">Bakery</input><br>
    <input type='checkbox' name="subcategory[]" value="Bar" id="bar">Bar</input><br>
    <input type='checkbox' name="subcategory[]" value="Cafe" id="cafe">Cafe</input><br>
    <input type='checkbox' name="subcategory[]" value="Dairy" id="dairy">Convience Store / Dairy</input><br>
    <input type='checkbox' name="subcategory[]" value="Fast food" id="fast food">Fast food</input><br>
    <input type='checkbox' name="subcategory[]" value="Restaurant" id="restaurant">Restaurant</input><br>
    <input type='checkbox' name="subcategory[]" value="Store" id="store">Store</input><br>
    <input type='checkbox' name="subcategory[]" value="Speciality" id="speciality">Speciality</input><br>
    <input type='checkbox' name="subcategory[]" value="Supermarket" id="supermarket">Supermarket</input><br>
    <input type='checkbox' name="subcategory[]" value="Takeaway" id="takeaway">Takeaway</input><br>
    <input type='checkbox' name="subcategory[]" value="OtherFDsub" id="otherFDsub">Other</input>

    <h2 class="titlepad">Additional filter options for your listing.</h2>

    <p class="checkpad">Type:</p>
    <input type='checkbox' name="type[]" value="American" id="american">American</input><br>
    <input type='checkbox' name="type[]" value="Chinese" id="chinese">Chinese</input><br>
    <input type='checkbox' name="type[]" value="Italian" id="italian">Italian</input><br>
    <input type='checkbox' name="type[]" value="Indian" id="indian">Indian</input><br>
    <input type='checkbox' name="type[]" value="French" id="french">French</input><br>
    <input type='checkbox' name="type[]" value="Japanese" id="japanese">Japanese</input><br>
    <input type='checkbox' name="type[]" value="Mexican" id="mexican">Mexican</input><br>
    <input type='checkbox' name="type[]" value="New Zealand" id="newzealand">New Zealand</input><br>
    <input type='checkbox' name="type[]" value="Thai" id="thai">Thai</input><br>
    <input type='checkbox' name="type[]" value="OtherFDtype" id="otherFDtype">Other</input><br>

	<p class="checkpad">Cost:</p>
    <input type='checkbox' name="cost[]" value="Under $15" id="under15"> Under $15</input>
    <input type='checkbox' name="cost[]" value="Under $25" id="under25"> Under $25</input>
    <input type='checkbox' name="cost[]" value="Under $30" id="under30"> Under $30</input><br>
    <input type='checkbox' name="cost[]" value="Under $40" id="under40"> Under $40</input>
    <input type='checkbox' name="cost[]" value="Under $50" id="under50"> Under $50</input>

    <p class="checkpad">Extras:</p>
    <input type='checkbox' name="extras[]" value="B.Y.O." id="byo"> B.Y.O.</input>
    <input type='checkbox' name="extras[]" value="Coffee" id="coffee"> Coffee</input>
    <input type='checkbox' name="extras[]" value="Gluten Free" id="glutenfree"> Gluten Free</input>
    <input type='checkbox' name="extras[]" value="Halal" id="halal"> Halal</input><br>
    <input type='checkbox' name="extras[]" value="Licensed" id="licensed"> Licensed</input>
    <input type='checkbox' name="extras[]" value="Organic" id="organic"> Organic</input>
    <input type='checkbox' name="extras[]" value="Vegan" id="vegan"> Vegan</input>
    <input type='checkbox' name="extras[]" value="Vegetarian" id="vegetarian"> Vegetarian</input>

    <p class="checkpad">Features:</p>
    <input type='checkbox' name="features[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input>
    <input type='checkbox' name="features[]" value="Children friendly" class="childrenfriendly"> Children friendly</input>
    <input type='checkbox' name="features[]" value="Dog friendly" class="dogfoodfriendly"> Dog friendly</input>
    <input type='checkbox' name="features[]" value="Bike friendly" class="bikefoodfriendly"> Bike friendly</input><br>
    <input type='checkbox' name="features[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input>
    <input type='checkbox' name="features[]" value="Female toilet" class="femaletoilet"> Female toilet</input>
    <input type='checkbox' name="features[]" value="Male toilet" class="maletoilet"> Male toilet</input>				    

</div>