<div style='display:none;' id='accommodationfilter'>

	<h2 class="titlepad">Subcategories.</h2>

    <input type='checkbox' name="subcategory[]" value="B&B" id="B&B"> Bed & Breakfast</input>
    <input type='checkbox' name="subcategory[]" value="Lodge" id="Lodge"> Lodge</input>
    <input type='checkbox' name="subcategory[]" value="Motel" id="Motel"> Motel</input>
    <input type='checkbox' name="subcategory[]" value="Motor Lodge" id="Motor Lodge"> Motor Lodge</input>
    <input type='checkbox' name="subcategory[]" value="OtherAcSub" id="OtherAcSub"> Others</input>

    <h2 class="titlepad">Additional filter options for your listing.</h2>

    <p class="checkpad">Type:</p>
    <input type='checkbox' name="type[]" value="Long term" id="Long term"> Long term</input>
    <input type='checkbox' name="type[]" value="Short term" id="Short term"> Short term</input>
    <input type='checkbox' name="type[]" value="1 night minimum" id="1 night minimum"> 1 night minimum</input>
    <input type='checkbox' name="type[]" value="2 nights minimum" id="2 nights minimum"> 2 nights minimum</input>
    <input type='checkbox' name="type[]" value="3 nights minimum" id="3 nights minimum"> 3 nights minimum</input>
    <input type='checkbox' name="type[]" value="4+ nights minimum" id="4+ nights minimum"> 4 or more nights minimum</input>
    <input type='checkbox' name="type[]" value="OtherAcType" id="OtherAcType"> Other</input>

	<p class="checkpad">Cost:</p>
    <input type='checkbox' name="cost[]" value="under $50, under fifty dollars, under 50 dollars" id="under50"> Under $50</input>
    <input type='checkbox' name="cost[]" value="under $100, under one hundred dollars, under 100 dollars" id="under100"> Under $100</input>
    <input type='checkbox' name="cost[]" value="under $200, under two hundred dollars, under 200 dolars" id="under200"> Under $200</input><br>

    <p class="checkpad">Extras:</p>
    <input type='checkbox' name="extras[]" value="Bathroom" id="Bathroom"> Bathroom</input>
    <input type='checkbox' name="extras[]" value="Breakfast" id="Breakfast"> Breakfast available</input>
    <input type='checkbox' name="extras[]" value="Dinner" id="Dinner"> Dinner available</input>
    <input type='checkbox' name="extras[]" value="Parking" id="Parking"> Parking</input>
    <input type='checkbox' name="extras[]" value="Pool Spa" id="Pool Spa"> Pool / Spa</input>
    <input type='checkbox' name="extras[]" value="Room service" id="Room service"> Room service</input>
    <input type='checkbox' name="extras[]" value="Shower" id="Shower"> Shower</input>
    <input type='checkbox' name="extras[]" value="Storage" id="Shower"> Storage</input>

    <p class="checkpad">Features:</p>
    <input type='checkbox' name="features[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input>
    <input type='checkbox' name="features[]" value="Children friendly" class="childrenfriendly"> Children friendly</input>
    <input type='checkbox' name="features[]" value="Dog friendly" class="dogfoodfriendly"> Dog friendly</input>
    <input type='checkbox' name="features[]" value="Bike friendly" class="bikefoodfriendly"> Bike friendly</input><br>
    <input type='checkbox' name="features[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input>
    <input type='checkbox' name="features[]" value="Female toilet" class="femaletoilet"> Female toilet</input>
    <input type='checkbox' name="features[]" value="Male toilet" class="maletoilet"> Male toilet</input>    

</div>