<div style='display:none;' id='sportsrecreationfilter'>
	
	<h2 class="titlepad">Subcategories.</h2>

    <input type='checkbox' name="subcategory[]" value="Basketball" id="Basketball"> Basketball</input>
    <input type='checkbox' name="subcategory[]" value="Biking" id="Biking"> Biking</input>
    <input type='checkbox' name="subcategory[]" value="Bowling" id="Bowling"> Bowling</input>
    <input type='checkbox' name="subcategory[]" value="Gym" id="Gym"> Gym</input>
    <input type='checkbox' name="subcategory[]" value="Hockey" id="Hockey"> Hockey</input>
    <input type='checkbox' name="subcategory[]" value="MartialArts" id="MartialArts"> Martial Arts</input>
    <input type='checkbox' name="subcategory[]" value="Rugby" id="Rugby"> Rugby</input>
    <input type='checkbox' name="subcategory[]" value="SoccerFootball" id="SoccerFootball"> Soccer / Football</input>
    <input type='checkbox' name="subcategory[]" value="TableTennis" id="TableTennis"> Table Tennis</input>
    <input type='checkbox' name="subcategory[]" value="Walkways" id="Walkways"> Walkways</input>
    <input type='checkbox' name="subcategory[]" value="OtherSRSub" id="OtherSRSub"> Other</input> 

    <h2 class="titlepad">Additional filter options for your listing.</h2>

    <!-- <p class="checkpad">Type:</p>
    <input type='checkbox' name="type[]" value="" id=""></input>
    <input type='checkbox' name="type[]" value="" id=""></input>
    <input type='checkbox' name="type[]" value="" id=""></input> -->

	<p>Cost:</p>
    <input type='checkbox' name="cost[]" value="Cost" id="Cost"> Cost</input>
    <input type='checkbox' name="cost[]" value="Free" id="Free"> Free</input>t>

    <!-- <p class="checkpad">Extras:</p>
    <input type='checkbox' name="extras[]" value="" id=""></input>
    <input type='checkbox' name="extras[]" value="" id=""></input>
    <input type='checkbox' name="extras[]" value="" id=""></input> -->

    <p class="checkpad">Features:</p>
    <input type='checkbox' name="features[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input>
    <input type='checkbox' name="features[]" value="Children friendly" class="childrenfriendly"> Children friendly</input>
    <input type='checkbox' name="features[]" value="Dog friendly" class="dogfoodfriendly"> Dog friendly</input>
    <input type='checkbox' name="features[]" value="Bike friendly" class="bikefoodfriendly"> Bike friendly</input><br>
    <input type='checkbox' name="features[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input>
    <input type='checkbox' name="features[]" value="Female toilet" class="femaletoilet"> Female toilet</input>
    <input type='checkbox' name="features[]" value="Male toilet" class="maletoilet"> Male toilet</input>	

</div>