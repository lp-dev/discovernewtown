<div style='display:none;' id='computersitfilter'>
	
	<h2 class="titlepad">Subcategories.</h2>

    <input type='checkbox' name="subcategory[]" value="Computer access" id="Computer access"> Computer access</input>
    <input type='checkbox' name="subcategory[]" value="Electronics" id="Electronics"> Electronics</input>
    <input type='checkbox' name="subcategory[]" value="Internet" id="Internet"> Internet</input>
    <input type='checkbox' name="subcategory[]" value="Printing" id="Printing"> Printing</input>
    <input type='checkbox' name="subcategory[]" value="Repair" id="Repair"> Repair</input>
    <input type='checkbox' name="subcategory[]" value="OtherCISub" id="OtherCISub"> Other</input>

    <h2 class="titlepad">Additional filter options for your listing.</h2>

    <!-- <p class="checkpad">Type:</p>
    <input type='checkbox' name="type[]" value="" id=""></input>
    <input type='checkbox' name="type[]" value="" id=""></input>
    <input type='checkbox' name="type[]" value="" id=""></input> -->

	<p>Cost:</p>
    <input type='checkbox' name="cost[]" value="Cost" id="Cost"> Cost</input>
    <input type='checkbox' name="cost[]" value="Free" id="Free"> Free</input>

    <!-- <p class="checkpad">Extras:</p>
    <input type='checkbox' name="extras[]" value="" id=""></input>
    <input type='checkbox' name="extras[]" value="" id=""></input>
    <input type='checkbox' name="extras[]" value="" id=""></input> -->

    <p class="checkpad">Features:</p>
    <input type='checkbox' name="features[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input>
    <input type='checkbox' name="features[]" value="Children friendly" class="childrenfriendly"> Children friendly</input>
    <input type='checkbox' name="features[]" value="Dog friendly" class="dogfoodfriendly"> Dog friendly</input>
    <input type='checkbox' name="features[]" value="Bike friendly" class="bikefoodfriendly"> Bike friendly</input><br>
    <input type='checkbox' name="features[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input>
    <input type='checkbox' name="features[]" value="Female toilet" class="femaletoilet"> Female toilet</input>
    <input type='checkbox' name="features[]" value="Male toilet" class="maletoilet"> Male toilet</input>

</div>