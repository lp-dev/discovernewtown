<div style='display:none;' id='communityfilter'>
	
	<h2 class="titlepad">Subcategories.</h2>

    <input type='checkbox' name="subcategory[]" value="ChurchReligion" id="ChurchReligion"> Church / Religion</input>
    <input type='checkbox' name="subcategory[]" value="CitizensAdviceBureau" id="CitizensAdviceBureau"> Citizens Advice Bureau</input>
    <input type='checkbox' name="subcategory[]" value="CommunityCentre" id="CommunityCentre"> Community centre</input>
    <input type='checkbox' name="subcategory[]" value="Library" id="Library"> Library</input>
    <input type='checkbox' name="subcategory[]" value="MeetingHall" id="MeetingHall"> Meeting hall</input>
    <input type='checkbox' name="subcategory[]" value="PublicToiletRestroom" id=""> Public toilet / Restroom</input>
    <input type='checkbox' name="subcategory[]" value="RetirementHomes" id="RetirementHomes"> Retirement homes</input>
    <input type='checkbox' name="subcategory[]" value="WorkIncome" id="WorkIncome"> Work & Income</input>
    <input type='checkbox' name="subcategory[]" value="OtherCoSub" id="OtherCoSub"> Other</input>

    <h2 class="titlepad">Additional filter options for your listing.</h2>

    <!-- <p class="checkpad">Type:</p>
    <input type='checkbox' name="type[]" value="" id=""></input>
    <input type='checkbox' name="type[]" value="" id=""></input>
    <input type='checkbox' name="type[]" value="" id=""></input>

	<p class="checkpad">Cost:</p>
	<input type='checkbox' name="cost[]" value="" id=""></input>
	<input type='checkbox' name="cost[]" value="" id=""></input>
	<input type='checkbox' name="cost[]" value="" id=""></input>

    <p class="checkpad">Extras:</p>
    <input type='checkbox' name="extras[]" value="" id=""></input>
    <input type='checkbox' name="extras[]" value="" id=""></input>
    <input type='checkbox' name="extras[]" value="" id=""></input>
 -->
    <p class="checkpad">Features:</p>
    <input type='checkbox' name="features[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input>
    <input type='checkbox' name="features[]" value="Children friendly" class="childrenfriendly"> Children friendly</input>
    <input type='checkbox' name="features[]" value="Dog friendly" class="dogfoodfriendly"> Dog friendly</input>
    <input type='checkbox' name="features[]" value="Bike friendly" class="bikefoodfriendly"> Bike friendly</input><br>
    <input type='checkbox' name="features[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input>
    <input type='checkbox' name="features[]" value="Female toilet" class="femaletoilet"> Female toilet</input>
    <input type='checkbox' name="features[]" value="Male toilet" class="maletoilet"> Male toilet</input>

</div>