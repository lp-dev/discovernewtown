<div style='display:none;' id='tradesservicesfilter'>
	
	<h2 class="titlepad">Subcategories.</h2>

    <input type='checkbox' name="subcategory[]" value="BicycleMechanic" id="BicycleMechanic"> Bicycle mechanic</input>
    <input type='checkbox' name="subcategory[]" value="Builder" id="Builder"> Builder</input>
    <input type='checkbox' name="subcategory[]" value="Carpenter" id="Carpenter"> Carpenter</input>
    <input type='checkbox' name="subcategory[]" value="Design" id="Design"> Design</input>
    <input type='checkbox' name="subcategory[]" value="Electrical" id="Electrical"> Electrical</input>
    <input type='checkbox' name="subcategory[]" value="Florist" id="Florist"> Florist</input>
    <input type='checkbox' name="subcategory[]" value="Glass" id="Glass"> Glass</input>
    <input type='checkbox' name="subcategory[]" value="Hire" id="Hire"> Hire</input>
    <input type='checkbox' name="subcategory[]" value="MaintenanceProperty" id="MaintenanceProperty"> Maintenance / Property</input>
    <input type='checkbox' name="subcategory[]" value="PaintersDecorators" id="PaintersDecorators"> Painters / Decorators</input>
    <input type='checkbox' name="subcategory[]" value="Plumbing" id="Plumbing"> Plumbing</input>
    <input type='checkbox' name="subcategory[]" value="Post" id="Post"> Post</input>
    <input type='checkbox' name="subcategory[]" value="Printing" id="Printing"> Printing</input>
    <input type='checkbox' name="subcategory[]" value="Property" id="Property"> Property</input>
    <input type='checkbox' name="subcategory[]" value="RealEstate" id="RealEstate"> Real Estate</input>
    <input type='checkbox' name="subcategory[]" value="Roofing" id="Roofing"> Roofing</input>
    <input type='checkbox' name="subcategory[]" value="Storage" id="Storage"> Storage</input>
    <input type='checkbox' name="subcategory[]" value="TravelAgency" id="TravelAgency"> Travel agency</input>
    <input type='checkbox' name="subcategory[]" value="OtherTSSub" id="OtherTSSub"> Other</input>

    <h2 class="titlepad">Additional filter options for your listing.</h2>

    <!-- <p class="checkpad">Type:</p>
    <input type='checkbox' name="type[]" value="" id=""></input>
    <input type='checkbox' name="type[]" value="" id=""></input>
    <input type='checkbox' name="type[]" value="" id=""></input>

	<p class="checkpad">Cost:</p>
	<input type='checkbox' name="cost[]" value="" id=""></input>
	<input type='checkbox' name="cost[]" value="" id=""></input>
	<input type='checkbox' name="cost[]" value="" id=""></input>

    <p class="checkpad">Extras:</p>
    <input type='checkbox' name="extras[]" value="" id=""></input>
    <input type='checkbox' name="extras[]" value="" id=""></input>
    <input type='checkbox' name="extras[]" value="" id=""></input> -->

    <p class="checkpad">Features:</p>
    <input type='checkbox' name="features[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input>
    <input type='checkbox' name="features[]" value="Children friendly" class="childrenfriendly"> Children friendly</input>
    <input type='checkbox' name="features[]" value="Dog friendly" class="dogfoodfriendly"> Dog friendly</input>
    <input type='checkbox' name="features[]" value="Bike friendly" class="bikefoodfriendly"> Bike friendly</input><br>
    <input type='checkbox' name="features[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input>
    <input type='checkbox' name="features[]" value="Female toilet" class="femaletoilet"> Female toilet</input>
    <input type='checkbox' name="features[]" value="Male toilet" class="maletoilet"> Male toilet</input>

</div>