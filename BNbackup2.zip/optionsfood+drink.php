				<div id='fooddrinkfilter'>
					<h4>Subcategory filters:</h4>

					<INPUT TYPE="checkbox" NAME="Signing_from" VALUE="Joes_page">

				    <input type='checkbox' name="subcategory[]" value="bakery" id="bakery">Bakery</input>
				    <input type='checkbox' name="subcategory[]" value="bar" id="bar">Bar</input>
				    <input type='checkbox' name="subcategory[]" value="cafe" id="cafe">Cafe</input>
				    <input type='checkbox' name="subcategory[]" value="dairy" id="dairy">Dairy</input>
				    <input type='checkbox' name="subcategory[]" value="restaurant" id="restaurant">Restaurant</input>
				    <input type='checkbox' name="subcategory[]" value="supermarket" id="supermarket">Supermarket</input>
				    <input type='checkbox' name="subcategory[]" value="takeaway" id="takeaway">Takeaway</input>
				    <input type='checkbox' name="subcategory[]" value="subotherfood+drink" id="subotherfood+drink">Other</input>

				    <h4>Additional filters:</h4>
				    <input type='checkbox' name="type[]" value="american" id="american">American</input>
				    <input type='checkbox' name="type[]" value="chinese" id="chinese">Chinese</input>
				    <input type='checkbox' name="type[]" value="italian" id="italian">Italian</input>
				    <input type='checkbox' name="type[]" value="indian" id="indian">Indian</input>
				    <input type='checkbox' name="type[]" value="french" id="french">French</input>
				    <input type='checkbox' name="type[]" value="japanese" id="japanese">Japanese</input>
				    <input type='checkbox' name="type[]" value="mexican" id="mexican">Mexican</input>
				    <input type='checkbox' name="type[]" value="new zealand" id="newzealand">New Zealand</input>
				    <input type='checkbox' name="type[]" value="thai" id="thai">Thai</input>
				    <input type='checkbox' name="type[]" value="otherfood+drink" id="otherfood+drink">Other</input>
				    <input type='checkbox' name="type[]" value="allfood+drink" id="allfood+drink">All</input><hr>

				    <input type='checkbox' name="price[]" value="under15" id="under15">Under $15</input>
				    <input type='checkbox' name="price[]" value="under25" id="under25">Under $25</input>
				    <input type='checkbox' name="price[]" value="under30" id="under30">Under $30</input>
				    <input type='checkbox' name="price[]" value="under40" id="under40">Under $40</input>
				    <input type='checkbox' name="price[]" value="under50" id="under50">Under $50</input><hr>

				    <input type='checkbox' name="preference[]" value="byo" id="byo">B.Y.O.</input>
				    <input type='checkbox' name="preference[]" value="coffee" id="coffee">Coffee</input>
				    <input type='checkbox' name="preference[]" value="glutenfree" id="glutenfree">Gluten Free</input>
				    <input type='checkbox' name="preference[]" value="halal" id="halal">Halal</input>
				    <input type='checkbox' name="preference[]" value="licensed" id="licensed">Licensed</input>
				    <input type='checkbox' name="preference[]" value="organic" id="organic">Organic</input>
				    <input type='checkbox' name="preference[]" value="vegan" id="vegan">Vegan</input>
				    <input type='checkbox' name="preference[]" value="vegetarian" id="vegetarian">Vegetarian</input><hr>

				    <input type='checkbox' name="features[]" value="wheelchairfood+drink" id="wheelchairfood+drink">Wheelchair friendly</input>
				    <input type='checkbox' name="features[]" value="childrenfood+drink" id="childrenfood+drink">Children friendly</input>
				    <input type='checkbox' name="features[]" value="dogfood+drink" id="dogfood+drink">Dog friendly</input>
				    <input type='checkbox' name="features[]" value="bikefood+drink" id="bikefood+drink">Bike friendly</input>
				    <input type='checkbox' name="features[]" value="accessiblefood+drink" id="accesiblefood+drink">Accessible toilet</input>
				    <input type='checkbox' name="features[]" value="femalefood+drink" id="femalefood+drink">Female toilet</input>
				    <input type='checkbox' name="features[]" value="malefood+drink" id="malefood+drink">Male toilet</input>			    

				</div>