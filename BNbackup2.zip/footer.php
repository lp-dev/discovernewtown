		<div class="modal fade" id="contact" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">

					<form class="form-horizontal" action='' id="contactform" method='post' >

						<div class="modal-header">
							<h3>Contact Discover Newtown</h3>
						</div>
						<div class="modal-body">
							<div class="form-group">
								<div class="col-lg-12">
									<input type="text" class="form-control" id="name" name="name" placeholder="Jane Doe">
								</div>
							</div>
							<div class="form-group">
								<div class="col-lg-12">
									<input type="email" class="form-control" id="email" name="email" placeholder="youremail@example.com">
								</div>
							</div>
							<div class="form-group">
								<div class="col-lg-12">
									<textarea class="form-control limit" rows="8" id="message" name="message"></textarea>
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<a class="btn btn-default" data-dismiss="modal">Close</a>
							<input type="submit" class="btn btn-primary" value="Send">
							<!-- <button class="btn btn-primary" type="submit">Send Message</a> -->
						</div>
					</form>

				</div>
			</div>
		</div>

	</div>
	<nav class="navbar navbar-default navbar-fixed-bottom">
		<div class="container">
			<a  href="index.php"><button type="button" class="btn btn-default footerbuttons"><img class="homeimg" src="img/btns/home.png" alt="home"></img>Home</button></a>
			<button type="button" class="btn btn-default footerbuttons" data-toggle="modal" data-target="#contact"><img class="contactimg" src="img/btns/contact.png" alt="contact"></img>Contact</button>

			<!-- <img src="..." alt="..." class="img-rounded"> -->
			<!-- <span class="glyphicon glyphicon-home" aria-hidden="true">Home</span>
			<span class="glyphicon glyphicon-earphone" aria-hidden="true">Contact</span> -->
		</div>
	</nav>
  </body>
</html>