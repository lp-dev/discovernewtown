<?php

$db = new mysqli('localhost', 'besthai1_dnuser', 'dn_15Connect', 'besthai1_dnlistings');
//$db = new mysqli('localhost', 'root', '', 'besthai1_dnlistings');

?>