<?php include 'header.php'; ?>

    <div class="container conmarg">
	  
<?php include 'menu/main.php'; ?>

<div class="col-md-6 middlebtmpad" id="col2">

    <h1>Link to website</h1><hr>
    
    <p>This can link directly to your website.</p>
    <h2 class="titlepad">Needing a website?</h2>
    <p>Discover Newtown offers a website building service.</p>
    <ul class="">
        <li>Have your own website name and email address.</li>
        <li>Webhosting, offering you a place to store your website online.</li>
    </ul>

    <p>Enquire now for more information</p>

    <button type="button" class="btn btn-default footerbuttons stretch websiteenquiry" data-toggle="modal" data-target="#contact"><img class="contactimg" src="img/btns/contact.png" alt="contact"></img>Contact us</button>
           
</div>

<?php include 'menu/blank.php'; ?>
	
<?php include 'footer.php'; ?>