<div style='display:none;' id='sportsrecreationfilter'>

    <div class="col-md-12">

        <div class="col-md-6">

            <h2 class="titlepad">Subcategories</h2>

            <input type='checkbox' name="subcategory[]" value="Athletics" id="Athletics"> Athletics</input><br>
            <input type='checkbox' name="subcategory[]" value="Basketball" id="Basketball"> Basketball</input><br>
            <input type='checkbox' name="subcategory[]" value="Biking" id="Biking"> Biking</input><br>
            <input type='checkbox' name="subcategory[]" value="Bowling" id="Bowling"> Bowling</input><br>
            <input type='checkbox' name="subcategory[]" value="Clubs" id="Clubs"> Clubs</input><br>
            <input type='checkbox' name="subcategory[]" value="Croquet" id="Croquet"> Croquet</input><br>
            <input type='checkbox' name="subcategory[]" value="Dance" id="Dance"> Dance</input><br>
            <input type='checkbox' name="subcategory[]" value="Golf" id="Golf"> Golf</input><br>
            <input type='checkbox' name="subcategory[]" value="Gym" id="Gym"> Gym</input><br>
            <input type='checkbox' name="subcategory[]" value="Gymnastics" id="Gymnastics"> Gymnastics</input><br>
            <input type='checkbox' name="subcategory[]" value="Hockey" id="Hockey"> Hockey</input><br>
            <input type='checkbox' name="subcategory[]" value="Martial arts" id="Martialarts"> Martial arts</input><br>
            <input type='checkbox' name="subcategory[]" value="Rugby" id="Rugby"> Rugby</input><br>
            <input type='checkbox' name="subcategory[]" value="Shooting" id="Shooting"> Shooting</input><br>
            <input type='checkbox' name="subcategory[]" value="Soccer Football" id="SoccerFootball"> Soccer / Football</input><br>
            <input type='checkbox' name="subcategory[]" value="Table tennis" id="Tabletennis"> Table Tennis</input><br>
            <input type='checkbox' name="subcategory[]" value="Tennis" id="Tennis"> Tennis</input><br>
            <input type='checkbox' name="subcategory[]" value="Volleyball" id="Volleyball"> Volleyball</input><br>
            <input type='checkbox' name="subcategory[]" value="Walkways" id="Walkways"> Walkways</input><br>
            <input type="text" name="subcategory[]" id="OtherSRsubcategory" placeholder="Add own suggestion"></input>
            <!-- <input type='checkbox' name="subcategory[]" value="OtherSRSub" id="OtherSRSub"> Other</input><br> --> 

        </div>

        <div class="col-md-6">

            <h2 class="titlepad">Type</h2>

            <input type='checkbox' name="type[]" value="Indoor" id="Indoor"> Indoor</input><br>
            <input type='checkbox' name="type[]" value="Outdoor" id="Outdoor"> Outdoor</input><br>
            <input type='checkbox' name="type[]" value="Covered" id="Covered"> Covered</input><br>
            <input type='checkbox' name="type[]" value="Uncovered" id="Uncovered"> Uncovered</input><br>
            <input type='checkbox' name="type[]" value="Club" id="Club"> Club</input><br>
            <input type='checkbox' name="type[]" value="Course" id="Course"> Course</input><br>
            <input type='checkbox' name="type[]" value="Court" id="Court"> Court</input><br>
            <input type='checkbox' name="type[]" value="Field" id="Field"> Field</input><br>
            <input type='checkbox' name="type[]" value="Park" id="Park"> Park</input><br>
            <input type='checkbox' name="type[]" value="Stadium" id="Stadium"> Stadium</input><br>
            <input type='checkbox' name="type[]" value="Track" id="Track"> Track</input><br>
            <input type='checkbox' name="type[]" value="Trail" id="Trail"> Trail</input><br>
            <input type='checkbox' name="type[]" value="Store Supplies" id="StoreSupplies"> Store / Supplies</input><br>
            <input type="text" name="type[]" id="OtherSRtype" placeholder="Add own suggestion"></input>

        </div>

    </div>
    <div class="col-md-12 twentyunderpad">

        <div class="col-md-6">

            <h2 class="titlepad">Cost</h2>

            <input type='checkbox' name="cost[]" value="Cost" id="Cost"> Cost</input><br>
            <input type='checkbox' name="cost[]" value="Free" id="Free"> Free</input><br>
            <input type="text" name="cost[]" id="OtherSRcost" placeholder="Add own suggestion"></input>

        </div>

        <div class="col-md-6">

            <h2 class="titlepad">Features</h2>

            <input type='checkbox' name="features[]" value="Wifi" id="wifi"> Free Wifi</input><br>
            <input type='checkbox' name="features[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input><br>
            <input type='checkbox' name="features[]" value="Children friendly" class="childrenfriendly"> Children friendly</input><br>
            <input type='checkbox' name="features[]" value="Dog friendly" class="dogfriendly"> Dog friendly</input><br>
            <input type='checkbox' name="features[]" value="Bike friendly" class="bikefriendly"> Bike friendly</input><br>
            <input type='checkbox' name="features[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input><br>
            <input type='checkbox' name="features[]" value="Female toilet" class="femaletoilet"> Female toilet</input><br>
            <input type='checkbox' name="features[]" value="Male toilet" class="maletoilet"> Male toilet</input><br> 
            
        </div>

    </div>

</div>