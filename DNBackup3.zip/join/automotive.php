<div style='display:none;' id='automotivefilter'>

    <div class="col-md-12 twentyunderpad">

        <div class="col-md-6">

            <h2 class="titlepad">Subcategories</h2>

            <input type='checkbox' name="subcategory[]" value="Audio" id="Audio"> Audio</input><br>
            <input type='checkbox' name="subcategory[]" value="Customisation" id="Customisation"> Customisation</input><br>
            <input type='checkbox' name="subcategory[]" value="Dealer" id=""> Dealer</input><br>
            <input type='checkbox' name="subcategory[]" value="Electrical" id="Electrical"> Electrical</input><br>
            <input type='checkbox' name="subcategory[]" value="Mechanic" id="Mechanic"> Mechanic</input><br>
            <input type='checkbox' name="subcategory[]" value="Parts" id="Parts"> Parts</input><br>
            <input type='checkbox' name="subcategory[]" value="Repair" id="Repair"> Repair</input><br>
            <input type='checkbox' name="subcategory[]" value="Service station" id="Service station"> Service station</input><br>
            <input type="text" name="subcategory[]" id="OtherAusubcategory" placeholder="Add own suggestion"></input>
            <!-- <input type='checkbox' name="subcategory[]" value="OtherAuSub" id="OtherAuSub"> Other</input><br> -->

        </div>

        <div class="col-md-6">

            <h2 class="titlepad">Features</h2>

            <input type='checkbox' name="features[]" value="Wifi" id="wifi"> Free Wifi</input><br>
            <input type='checkbox' name="features[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input><br>
            <input type='checkbox' name="features[]" value="Children friendly" class="childrenfriendly"> Children friendly</input><br>
            <input type='checkbox' name="features[]" value="Dog friendly" class="dogfriendly"> Dog friendly</input><br>
            <input type='checkbox' name="features[]" value="Bike friendly" class="bikefriendly"> Bike friendly</input><br>
            <input type='checkbox' name="features[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input><br>
            <input type='checkbox' name="features[]" value="Female toilet" class="femaletoilet"> Female toilet</input><br>
            <input type='checkbox' name="features[]" value="Male toilet" class="maletoilet"> Male toilet</input><br> 

        </div>

    </div>

</div>