<div style='display:none;' id='computersitfilter'>

    <div class="col-md-12">

        <div class="col-md-6">

            <h2 class="titlepad">Subcategories</h2>

            <input type='checkbox' name="subcategory[]" value="Computer access" id="Computer access"> Computer access</input><br>
            <input type='checkbox' name="subcategory[]" value="Electronics" id="Electronics"> Electronics</input><br>
            <input type='checkbox' name="subcategory[]" value="Internet" id="Internet"> Internet</input><br>
            <input type='checkbox' name="subcategory[]" value="Printing" id="Printing"> Printing</input><br>
            <input type='checkbox' name="subcategory[]" value="Repair" id="Repair"> Repair</input><br>
            <input type="text" name="subcategory[]" id="OtherCIsubcategory" placeholder="Add own suggestion"></input>
            <!-- <input type='checkbox' name="subcategory[]" value="OtherCISub" id="OtherCISub"> Other</input><br> -->

        </div>

        <div class="col-md-6">

            <h2 class="titlepad">Cost</h2>

            <input type='checkbox' name="cost[]" value="Cost" id="Cost"> Cost</input><br>
            <input type='checkbox' name="cost[]" value="Free" id="Free"> Free</input><br>
            <input type="text" name="cost[]" id="OtherCIcost" placeholder="Add own suggestion"></input>


        </div>

    </div>
    <div class="col-md-12 twentyunderpad">

        <div class="col-md-6">

        <h2 class="titlepad">Features</h2>

            <input type='checkbox' name="features[]" value="Wifi" id="wifi"> Free Wifi</input><br>
            <input type='checkbox' name="features[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input><br>
            <input type='checkbox' name="features[]" value="Children friendly" class="childrenfriendly"> Children friendly</input><br>
            <input type='checkbox' name="features[]" value="Dog friendly" class="dogfriendly"> Dog friendly</input><br>
            <input type='checkbox' name="features[]" value="Bike friendly" class="bikefriendly"> Bike friendly</input><br>
            <input type='checkbox' name="features[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input><br>
            <input type='checkbox' name="features[]" value="Female toilet" class="femaletoilet"> Female toilet</input><br>
            <input type='checkbox' name="features[]" value="Male toilet" class="maletoilet"> Male toilet</input><br> 

        </div>

    </div>

</div>