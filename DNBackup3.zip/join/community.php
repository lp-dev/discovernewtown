<div style='display:none;' id='communityfilter'>

    <div class="col-md-12 twentyunderpad">

        <div class="col-md-6">

            <h2 class="titlepad">Subcategories</h2>

            <input type='checkbox' name="subcategory[]" value="Church Religion" id="ChurchReligion"> Church / Religion</input><br>
            <input type='checkbox' name="subcategory[]" value="Charity" id="Charity"> Charity</input><br>
            <input type='checkbox' name="subcategory[]" value="Citizens advice bureau" id="CitizensAdviceBureau"> Citizens Advice Bureau</input><br>
            <input type='checkbox' name="subcategory[]" value="Community centre" id="CommunityCentre"> Community centre</input><br>
            <input type='checkbox' name="subcategory[]" value="Culture" id="Culture"> Culture</input><br>
            <input type='checkbox' name="subcategory[]" value="Event" id="Event"> Event</input><br>
            <input type='checkbox' name="subcategory[]" value="Foundation" id="Foundation"> Foundation</input><br>
            <input type='checkbox' name="subcategory[]" value="Government" id="Government"> Government</input><br>
            <input type='checkbox' name="subcategory[]" value="Group" id="Group"> Group</input><br>
            <input type='checkbox' name="subcategory[]" value="Library" id="Library"> Library</input><br>
            <input type='checkbox' name="subcategory[]" value="Learning" id="Learning"> Learning</input><br>
            <input type='checkbox' name="subcategory[]" value="Public service" id="Public service"> Public service</input><br>
            <input type='checkbox' name="subcategory[]" value="Meeting hall" id="MeetingHall"> Meeting hall</input><br>
            <input type='checkbox' name="subcategory[]" value="Organisation" id="Organisation"> Organisation</input><br>
            <input type='checkbox' name="subcategory[]" value="Public toilet Restroom" id=""> Public toilet / Restroom</input><br>
            <input type='checkbox' name="subcategory[]" value="Retirement homes" id="RetirementHomes"> Retirement home</input><br>
            <input type='checkbox' name="subcategory[]" value="Support Guidance" id="SupportGuidance"> Support / Guidance</input><br>
            <input type='checkbox' name="subcategory[]" value="Venue" id="Venue"> Venue</input><br>
            <input type='checkbox' name="subcategory[]" value="Work & Income" id="WorkIncome"> Work & Income</input><br>
            <input type="text" name="subcategory[]" id="OtherCosubcategory" placeholder="Add own suggestion"></input>
            <!-- <input type='checkbox' name="subcategory[]" value="OtherCoSub" id="OtherCoSub"> Other</input><br> -->

        </div>

        <div class="col-md-6">

            <h2 class="titlepad">Features</h2>

            <input type='checkbox' name="features[]" value="Wifi" id="wifi"> Free Wifi</input><br>
            <input type='checkbox' name="features[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input><br>
            <input type='checkbox' name="features[]" value="Children friendly" class="childrenfriendly"> Children friendly</input><br>
            <input type='checkbox' name="features[]" value="Dog friendly" class="dogfriendly"> Dog friendly</input><br>
            <input type='checkbox' name="features[]" value="Bike friendly" class="bikefriendly"> Bike friendly</input><br>
            <input type='checkbox' name="features[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input><br>
            <input type='checkbox' name="features[]" value="Female toilet" class="femaletoilet"> Female toilet</input><br>
            <input type='checkbox' name="features[]" value="Male toilet" class="maletoilet"> Male toilet</input><br> 

        </div>

    </div>

</div>