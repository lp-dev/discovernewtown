<div style='display:none;' id='healthbeautyfilter'>

    <div class="col-md-12">

        <div class="col-md-6">

            <h2 class="titlepad">Subcategories</h2>

            <input type='checkbox' name="subcategory[]" value="Beauty" id="Beauty"> Beauty</input><br>
            <input type='checkbox' name="subcategory[]" value="Eyebrow" id="Eyebrow"> Eyebrow</input><br>
            <input type='checkbox' name="subcategory[]" value="Eyelash" id="Eyelash"> Eyelash</input><br>
            <input type='checkbox' name="subcategory[]" value="Facial" id="Facial"> Facial</input><br>
            <input type='checkbox' name="subcategory[]" value="General health" id="General health"> General health</input><br>
            <input type='checkbox' name="subcategory[]" value="Hairdresser" id="Hairdresser"> Hairdresser</input><br>
            <input type='checkbox' name="subcategory[]" value="Manicure" id="Manicure"> Manicure</input><br>
            <input type='checkbox' name="subcategory[]" value="Massage" id="Massage"> Massage</input><br>
            <input type='checkbox' name="subcategory[]" value="Pedicure" id="Pedicure"> Pedicure</input><br>
            <input type='checkbox' name="subcategory[]" value="Prescription" id="Prescription"> Prescription</input><br>
            <input type='checkbox' name="subcategory[]" value="Pharmacy" id="Pharmacy"> Pharmacy</input><br>
            <input type='checkbox' name="subcategory[]" value="Products Supplies" id="ProductsSupplies"> Products / Supplies</input><br>
            <input type='checkbox' name="subcategory[]" value="Nails" id="Nails"> Nails</input><br>
            <input type='checkbox' name="subcategory[]" value="Skincare" id="Skincare"> Skincare</input><br>
            <input type='checkbox' name="subcategory[]" value="Spray tan" id="SprayTan"> Spray tan</input> <br>         
            <input type='checkbox' name="subcategory[]" value="Sunbed" id="Sunbed"> Sunbed</input><br>
            <input type='checkbox' name="subcategory[]" value="Supplements Nutrition" id="SupplementsNutrition"> Supplements / Nutrition</input><br>
            <input type='checkbox' name="subcategory[]" value="Waxing" id="Waxing"> Waxing</input><br>
            <input type="text" name="subcategory[]" id="OtherHBsubcategory" placeholder="Add own suggestion"></input>
            <!-- <input type='checkbox' name="subcategory[]" value="OtherHBSub" id="OtherHBSub"> Other</input><br> -->

        </div>

        <div class="col-md-6">

            <h2 class="titlepad">Extras</h2>

            <input type='checkbox' name="extras[]" value="Appointment" id="Appointment"> Appointment</input><br>
            <input type='checkbox' name="extras[]" value="Walk-in" id="Walk-in"> Walk-in</input><br>
            <input type="text" name="extras[]" id="OtherHBextras" placeholder="Add own suggestion"></input>

        </div>

    </div>
    <div class="col-md-12 twentyunderpad">

        <div class="col-md-6">

        <h2 class="titlepad">Features</h2>

            <input type='checkbox' name="features[]" value="Wifi" id="wifi"> Free Wifi</input><br>
            <input type='checkbox' name="features[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input><br>
            <input type='checkbox' name="features[]" value="Children friendly" class="childrenfriendly"> Children friendly</input><br>
            <input type='checkbox' name="features[]" value="Dog friendly" class="dogfriendly"> Dog friendly</input><br>
            <input type='checkbox' name="features[]" value="Bike friendly" class="bikefriendly"> Bike friendly</input><br>
            <input type='checkbox' name="features[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input><br>
            <input type='checkbox' name="features[]" value="Female toilet" class="femaletoilet"> Female toilet</input><br>
            <input type='checkbox' name="features[]" value="Male toilet" class="maletoilet"> Male toilet</input><br> 

        </div>

    </div>

</div>