<div style='display:none;' id='medicalfilter'>

    <div class="col-md-12">

        <div class="col-md-6">

            <h2 class="titlepad">Subcategories</h2>

            <input type='checkbox' name="subcategory[]" value="Acupuncture" id="Acupuncture"> Acupuncture</input><br>
            <input type='checkbox' name="subcategory[]" value="Dentist" id="Dentist"> Dentist</input><br>
            <input type='checkbox' name="subcategory[]" value="Doctor" id="Doctor"> Doctor</input><br>
            <input type='checkbox' name="subcategory[]" value="Hospital" id="Hospital"> Hospital</input><br>
            <input type='checkbox' name="subcategory[]" value="Laboratory" id="Laboratory"> Laboratory</input><br>
            <input type='checkbox' name="subcategory[]" value="Pharmacy" id="Pharmacy"> Pharmacy</input><br>
            <input type='checkbox' name="subcategory[]" value="Physio" id="Physio"> Physio</input><br>
            <input type='checkbox' name="subcategory[]" value="Specialists" id="Specialists"> Specialists</input><br>
            <input type="text" name="subcategory[]" id="OtherMesubcategory" placeholder="Add own suggestion"></input>
            <!-- <input type='checkbox' name="subcategory[]" value="OtherMeSub" id="OtherMeSub"> Other</input><br> -->

        </div>

        <div class="col-md-6">

            <h2 class="titlepad">Extras</h2>

            <input type='checkbox' name="extras[]" value="Appointment" id="Appointment"> Appointment</input><br>
            <input type='checkbox' name="extras[]" value="Walk-in" id="Walk-in"> Walk-in</input><br>
            <input type="text" name="extras[]" id="OtherMeextras" placeholder="Add own suggestion"></input>

        </div>

    </div>
    <div class="col-md-12 twentyunderpad">

        <div class="col-md-6">

        <h2 class="titlepad">Features</h2>

            <input type='checkbox' name="features[]" value="Wifi" id="wifi"> Free Wifi</input><br>
            <input type='checkbox' name="features[]" value="Wheelchair friendly" class="wheelchairfriendly"> Wheelchair friendly</input><br>
            <input type='checkbox' name="features[]" value="Children friendly" class="childrenfriendly"> Children friendly</input><br>
            <input type='checkbox' name="features[]" value="Dog friendly" class="dogfriendly"> Dog friendly</input><br>
            <input type='checkbox' name="features[]" value="Bike friendly" class="bikefriendly"> Bike friendly</input><br>
            <input type='checkbox' name="features[]" value="Accessible toilet" class="accesibletoilet"> Accessible toilet</input><br>
            <input type='checkbox' name="features[]" value="Female toilet" class="femaletoilet"> Female toilet</input><br>
            <input type='checkbox' name="features[]" value="Male toilet" class="maletoilet"> Male toilet</input><br> 

        </div>

    </div>

</div>