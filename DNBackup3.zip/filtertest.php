<?php
		
	echo ". <hr>";		
	echo "Premium listing search = ".$sql." .<br><br>";
	echo "Basic listing search = ".$sql2." .";

?>