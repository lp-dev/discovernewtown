        <button type="button" class="btn btn-default headerelement stretch showmenu"><img class="joinimg " src="img/btns/menu.png" alt="category menu">Open menu</img></button>

        <div class="panel panel-default catmenu hidemenu">
            <div class="btn-group-vertical" role="group" aria-label="...">
                <a href="emergency"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/emergency.png" alt="emergency">Emergency</img></button></a>
                <a href="events"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/events.png" alt="events">Events</img></button></a>                
                <a href="accommodation"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/a.png" alt="A">Accommodation</img></button></a>
                <a href="automotive"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/a.png" alt="A">Automotive</img></button></a>
                <a href="banking+finance"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/b.png" alt="B">Banking & Finance</img></button></a>
                <a href="community"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/c.png" alt="C">Community</img></button></a>
                <a href="computers+it"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/c.png" alt="C">Computers & I.T.</img></button></a>
                <a href="education"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/e.png" alt="E">Education</img></button></a>
                <a href="entertainment"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/e.png" alt="E">Entertainment</img></button></a>
                <a href="food+drink"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/f.png" alt="F">Food & Drink</img></button></a>
                <a href="health+beauty"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/h.png" alt="H">Health & Beauty</img></button></a>
                <a href="medical.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/m.png" alt="M">Medical</img></button></a>
                <a href="retail+shopping.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/r.png" alt="R">Retail & Shopping</img></button></a>
                <a href="sports+recreation.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/s.png" alt="S">Sports & Recreation</img></button></a>
                <a href="trades+services.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/t.png" alt="T">Trades & Services</img></button></a>
                <a href="other.php"><button type="button" class="btn btn-default buttonmenu"><img class="menuimg" src="img/menu/other.png" alt="...">Other</img></button></a>
            </div>
        </div>