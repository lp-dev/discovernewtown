      <div class="col-md-3" id="col1">
      	<?php include 'menu/addsearch.php'; ?>
 		<?php include 'menu/addmenu.php'; ?>
        <a  href="#"><button type="button" class="btn btn-default headerelement stretch"><img class="filterimg" src="img/btns/filter.png" alt="filter"></img>Filter listings</button></a>
      </div>