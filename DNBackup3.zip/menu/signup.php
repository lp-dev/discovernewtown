      <div class="col-md-3 middlebtmpad" id="col1">
      	<?php include 'menu/addsearch.php'; ?>
 		<?php include 'menu/addmenu.php'; ?>
<!--         <a  href="premium.php" target="_blank"><button type="button" class="btn btn-default headerelement stretch"><img class="filterimg" src="img/btns/premium.png" alt="premium button"></img>View example</button></a> -->
        <!-- <a  href="free.php" target="_blank"><button type="button" class="btn btn-default headerelement stretch"><img class="filterimg" src="img/btns/free.png" alt="free button"></img>Free example</button></a> -->
      </div>