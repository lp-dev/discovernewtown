        <form class="input-group headerelement" role="search" method="POST" action="search.php">
          <input type="text" class="form-control" name="searchterm" id="searchterm" placeholder="Search all listings">
          <span class="input-group-btn">
            <button class="btn btn-default" type="submit" value="Search">Search</button>
          </span>
        </form>