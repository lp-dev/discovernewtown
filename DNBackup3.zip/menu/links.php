
        <!-- <button type="button" class="btn btn-default headerelement stretch showfb showlinks"><img class="joinimg " src="img/btns/menu.png" alt="Facebook module">Open links</img></button> -->

 		<!-- <div class="linksmenu hidemenu"> -->
        <div class="linksmenu">

	        <!-- <a href="signup.php" target="_blank"><button type="button" class="btn btn-default headerelement stretch"><img class="joinimg" src="img/btns/join.png" alt="join">Sign up here.</img></button></a> -->
	        <a href="http://www.discovernewtown.co.nz/forum" target="_blank"><button type="button" class="btn btn-default headerelement stretch"><img class="joinimg" src="img/btns/join.png" alt="join">View noticeboard</img></button></a>
	        <a href="https://www.facebook.com/discovernewtown" target="_blank"><button type="button" class="btn btn-default headerelement stretch"><img class="joinimg" src="img/btns/join.png" alt="join">View Facebook</img></button></a>
	   
	    </div>

        <img src="img/home-ad.jpg" class="img-responsive stretch" alt="Home ad image">


    </div>

	