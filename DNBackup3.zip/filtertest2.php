<?php
		
	echo ". <hr>";		
	echo "Special listing search = ".$sql13." .<br><br>";
	echo "Premium listing search = ".$sql11." .<br><br>";
	echo "Basic listing search = ".$sql12." .";

?>