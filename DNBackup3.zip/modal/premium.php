		<div class="modal fade" id="premiummodal" tabindex="-1" role="dialog" aria-labelledby="premiummodallabel">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h3 class="modal-title" id="premiummodallabel">Premium feature</h3>
					</div>
					<div class="modal-body">
						<p>Premium features provide enhanced ways to promote your business. They may incur extra charges but not before consultation. These details are used for indication and no obligations apply at this stage.</p>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>