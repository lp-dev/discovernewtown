<?php include 'header.php'; ?>

<?php include 'alertemail.php'; ?>

	<div class="container conmarg">

		<?php include 'menu/home.php'; ?>

		<div class="col-md-9 holdermiddle">

	  	<h1>Under Construction</h1><hr>

			<div class="col-md-12 listingpadding">
						<div class="col-md-4 listingpadding">
			  				<a href=""><img src="img/basic/nolistingimg.jpg" class="img-responsive listimg" alt="nolisting"></a>
				  		</div>
				  		<div class="col-md-4">
				  			<h4 class="list-group-item-heading">No details to show.</h4>
		    				<p class="list-group-item-text"></p>
		    				<p class="list-group-item-text"></p>
				  		</div>
				  		<div class="col-md-4 listingpadding">
				  			<p class="list-group-item-text"></p>
				  			<!-- <button type="button" class="btn btn-default tenpad listingbtn" data-toggle="modal" data-target="#featuresmodal"><img class="listingimg" src="img/btns/features.png" alt="features">View features</button> -->
				  			<a href=""><button type="button" class="btn btn-default tenpad listingbtn"><img class="listingimg" src="img/btns/nowebpage.png" alt="webpage">More info</button></a>
				  		</div>
			</div>
			<!-- <div class="col-md-12 listingpadding twentypad">
						<div class="col-md-4 listingpadding">
			  				<a href=""><img src="img/basic/listingimg.jpg" class="img-responsive listimg" alt="nolisting"></a>
				  		</div>
				  		<div class="col-md-4">
				  			<h4 class="list-group-item-heading">Name</h4>
		    				<p class="list-group-item-text">Address</p>
		    				<p class="list-group-item-text">Phone number</p>
				  		</div>
				  		<div class="col-md-4 listingpadding">
				  			<p class="list-group-item-text">Description</p>
				  			<a href=""><button type="button" class="btn btn-default tenpad listingbtn"><img class="listingimg" src="img/btns/nowebpage.png" alt="webpage">More info</button></a>
				  		</div>
			</div> -->	 
		</div>				

	</div>

<?php include 'footer.php'; ?>